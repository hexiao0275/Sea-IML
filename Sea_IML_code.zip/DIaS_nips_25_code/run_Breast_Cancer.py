#-*- coding : utf-8 -*-
import os,csv,re
import pandas as pd
import numpy as np
import scanpy as sc
import matplotlib.pyplot as plt
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score
from stMMR.utils import *
from stMMR.process import *
from stMMR import train_model_hbc
import sklearn
from sklearn.metrics import confusion_matrix
from scipy.optimize import linear_sum_assignment


device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def spatial_construct_graph1(adata, radius=50):

    coor = pd.DataFrame(adata.obsm['spatial'])
    coor.index = adata.obs.index
    coor.columns = ['imagerow', 'imagecol']
    A=np.zeros((coor.shape[0],coor.shape[0]))

    # print("coor:", coor)
    nbrs = sklearn.neighbors.NearestNeighbors(radius=radius).fit(coor)
    distances, indices = nbrs.radius_neighbors(coor, return_distance=True)

    for it in range(indices.shape[0]):
        A[[it] * indices[it].shape[0], indices[it]]=1

    print('The graph contains %d edges, %d cells.' % (sum(sum(A)), adata.n_obs))
    print('%.4f neighbors per cell on average.' % (sum(sum(A)) / adata.n_obs))

    graph_nei = torch.from_numpy(A)

    graph_neg = torch.ones(coor.shape[0],coor.shape[0]) - graph_nei

    sadj = sp.coo_matrix(A, dtype=np.float32)
    sadj = sadj + sadj.T.multiply(sadj.T > sadj) - sadj.multiply(sadj.T > sadj)
    # nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    # nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    return sadj, graph_nei, graph_neg#, nsadj

def load_data(dataset):
    print("load Spatial mgcn data:")
    path = "Data/" + dataset + "/Spatial_MGCN.h5ad"
    adata = sc.read_h5ad(path)
    features = torch.FloatTensor(adata.X)
    labels = adata.obs['ground']

    fadj = adata.obsm['fadj']
    sadj = adata.obsm['sadj']
    nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    graph_nei = torch.LongTensor(adata.obsm['graph_nei'])
    graph_neg = torch.LongTensor(adata.obsm['graph_neg'])
    print("done")
    return adata, features, labels, nfadj, nsadj, graph_nei, graph_neg



def load_data_text(dataset):
    print("load Spatial mgcn data:")
    path = "generate_data/" + dataset + "/Spatial_MGCN.h5ad"
    adata = sc.read_h5ad(path)
    features = torch.FloatTensor(adata.X)
    labels = adata.obs['ground']
    fadj = adata.obsm['fadj']
    sadj = adata.obsm['sadj']
    nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    graph_nei = torch.LongTensor(adata.obsm['graph_nei'])
    graph_neg = torch.LongTensor(adata.obsm['graph_neg'])
    print("done")
    return adata, features, labels, nfadj, nsadj, graph_nei, graph_neg

def process_genes_and_adata(input_dir_text, adata,n_top_genes=128):
    # 读取文本文件中的基因名称
    with open(input_dir_text, "r") as file:
        text_genes_txt = file.read().splitlines()

    # 创建一个布尔值的Series，索引为adata的变量名
    gene_text = pd.Series(False, index=adata.var_names)

    # 遍历基因列表，检查每个基因是否在adata的变量名中
    for gene in text_genes_txt:
        if gene in adata.var_names:
            gene_text.loc[gene] = True

    # 计算True的数量并打印
    true_count = gene_text.sum()
    print("Number of True values in gene_text:", n_top_genes)

    # 根据gene_text筛选adata中的基因
    adata_text = adata[:, gene_text]

    # 进行高变异基因分析
    sc.pp.highly_variable_genes(adata_text, flavor="seurat_v3", n_top_genes=true_count)

    # 标准化每个细胞的表达量
    # sc.pp.normalize_per_cell(adata_text)
    sc.pp.normalize_total(adata_text)

    # # 对数转换
    sc.pp.log1p(adata_text)

    # 返回处理后的adata
    return adata_text

database = "Human_Breast_Cancer_MGCN"
section_id = "V1_Breast_Cancer_Block_A_Section_1"

database_text_all = "Human_Breast_Cancer"

k=20

im_re = pd.read_csv(os.path.join('Data',
              "V1_Breast_Cancer_Block_A_Section_1", "image_representation/VIT_pca_representation.csv"), header=0, index_col=0, sep=',')
print(section_id, k)

adata, features, labels, fadj, sadj, graph_nei, graph_neg = load_data(database)

adata_text_all, _, _, _, _, _, _ = load_data_text(database_text_all)

input_dir_text = 'Data/Human_Breast_Cancer_MGCN/text_guide_gene_HBD.txt'
adata_text = process_genes_and_adata(input_dir_text, adata_text_all, n_top_genes=1)
adata.text = adata_text

adata.obsm["im_re"] = im_re

Ann_df = pd.read_csv("Data/{}/metadata.tsv".format(section_id), sep="	", header=0, na_filter=False,
                     index_col=0)
adata.obs['Ground Truth'] = Ann_df.loc[adata.obs_names, 'ground_truth']
adata.obs['ground_truth'] = adata.obs['Ground Truth']

_, graph_nei_sp, graph_neg_sp = spatial_construct_graph1(adata, radius=600)
_, graph_nei, graph_neg = spatial_construct_graph1(adata, radius=300)



positions = adata.obsm['spatial']  

fadj = torch.tensor(positions, dtype=torch.float64).to(device)

sadj = sadj.to(device)
fadj = fadj.to(device)

graph_nei_np = graph_nei.numpy()
graph_neg_np = graph_neg.numpy()

# adata.obsm["sadj_sp"] = sadj_sp
adata.obsm["graph_nei"] = graph_nei_np
adata.obsm["graph_neg"] = graph_neg_np
adata.obsm["graph_nei_sp"] = graph_nei_sp.numpy()
adata.obsm["graph_neg_sp"] = graph_neg_sp.numpy()


rand_seeds = [2300,500]

best_ari = -1
best_nmi = -1
best_seed = None
results = []  


for seed in rand_seeds:
    adata = train_model_hbc.train(adata, fadj, sadj, k , n_epochs=500, h=[128, 32], lr=0.0005, enhancement=False, radius=0, random_seed=seed)

    obs_df = adata.obs.dropna()

    ARI = adjusted_rand_score(obs_df['stMMR'], obs_df['Ground Truth'])
    NMI = normalized_mutual_info_score(obs_df['stMMR'], obs_df['Ground Truth'])
    
    print('Random Seed = %d, Adjusted Rand Index = %.5f, Normalized Mutual Information = %.5f' % (seed, ARI, NMI))
    
    results.append((seed, ARI, NMI))


    if ARI > best_ari:
        best_ari = ARI
        best_seed = seed
    if NMI > best_nmi:
        best_nmi = NMI
        best_seed = seed



print("\nAll Seed Results:")
for seed, ari, nmi in results:
    print(f"Seed: {seed}, ARI: {ari:.5f}, NMI: {nmi:.5f}")


print(f'Section ID: {section_id}, Adjusted Rand Index (ARI) = {ARI:.2f}, Normalized Mutual Information (NMI) = {NMI:.2f}')



