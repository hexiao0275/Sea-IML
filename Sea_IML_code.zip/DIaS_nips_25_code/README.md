

## 1 Introduction

stMMR is a multi-modal feature representation approach based on similarity contrastive learning, specifically designed for spatial transcriptomics. stMMR can effectively integrates gene expression, spatial location, and histological imaging information.

stMMR uses self-attention module for deep embedding of features within unimodal and incorporates similarity contrastive learning for integrating features across modalities. It demonstrates superior

## 2 Installation

stMMR is implemented using Python 3.9.1 and Pytorch 1.11.1.

Users can install stMMR through this repository directly or PyPI.

### 2.1 Install from Github

```
git clone https://github.com/nayu0419/stMMR.git
cd stMMR
python setup.py build
python setup.py install --user
```

### 2.2 Install from PyPI

```
pip3 install stMMR
```

### 2.3 Requirements

* numpy~=1.21.5
* numba~=0.55.1
* scanpy~=1.9.3
* torch~=1.11.0
* munkres~=1.1.4
* pandas~=1.3.5
* scikit-learn~=1.0.2
* anndata~=0.8.0
* scipy~=1.7.3
* matplotlib~=3.5.2

pip install -r requirements.txt  -i https://pypi.tuna.tsinghua.edu.cn/simple 


## 3 Datasets

All datasets used in this paper are publicly available. Users can download them from the links below.

* **DLPFC**  
The primary source: <https://github.com/LieberInstitute/spatialLIBD>.  
The processed version: <https://www.nature.com/articles/s41593-020-00787-0>.

* **Human breast cancer**  
The primary source: <https://www.10xgenomics.com/resources/datasets/human-breast-cancer-block-a-section-1-1-standard-1-1-0>.  
The processed version: <https://github.com/JinmiaoChenLab/SEDR_analyses/>.

* **Chicken heart**  
The primary source: <https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE149457>.

* **Lung cancer (9-1) nanostring**  
The primary source: <https://nanostring.com/products/cosmx-spatial-molecular-imager/nsclc-ffpe-dataset>.

* **Human pancreatic ductal adenocarcinoma**  
The primary source: <https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM3036911>.

* **Mouse anterior brain**  
The primary source: <https://www.10xgenomics.com/resources/datasets/mouse-brain-serial-section-1-sagittal-anterior-1-standard-1-1-0>.

Processed datasets are also available at SODB and can be loaded by PySODB. Here, we use DLPFC dataset as an example.


**Step1: Install PySODB**

```bash
git clone https://github.com/TencentAILabHealthcare/pysodb.git
cd pysodb/
python setup.py install
```

**Step2: Download DLPFC Dataset**

```Python
import pysodb

# Initialization
sodb = pysodb.SODB()

# load whole dataset
adataset = sodb.load_dataset('maynard2021trans')

# load a specific experiment
adata = sodb.load_experiment('maynard2021trans','151507')
```
