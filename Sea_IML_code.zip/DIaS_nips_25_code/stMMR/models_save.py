import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from sklearn.cluster import KMeans
import torch.optim as optim
from random import shuffle
import pandas as pd
import numpy as np
import scanpy as sc
from stMMR.layers import GraphConvolution,SelfAttention,MLP,MGCN,decoder
import sys

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, out)
        self.dropout = dropout
    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim1, hidden_dim2, dropout):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim1)
        self.fc2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        return x
    
class stMMR(nn.Module):
    def __init__(self,nfeatX,nfeatI,nfeatT, hidden_dims,fft_ratio,feature_num,sadj,fadj):
        super(stMMR, self).__init__()

        self.sadj =sadj
        self.fadj =fadj
        dropout = 0.1
        self.nfeatX = nfeatX
        self.nfeatI = nfeatI
        self.nfeatT = nfeatT
        self.GCN_G = GCN(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_A = GCN(nfeatI, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_T = GCN(nfeatT, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_G = MLP(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_A = MLP(nfeatI, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_T = MLP(nfeatT, hidden_dims[0], hidden_dims[1], dropout)

        self.fc = nn.Linear(hidden_dims[1]*3, hidden_dims[1])
        self.ZINB = decoder(hidden_dims[1],nfeatX)
        # self.ZINB_T = decoder(hidden_dims[1],nfeatT)

        d_model = hidden_dims[1]
        n_heads = 2
        d_ff = hidden_dims[1]*2
        n_layers = 1
        # # Create TransformerEncoder model
        self.transformer = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        self.transformer_2 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        self.transformer_3 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)

        self.transformer_all = TransformerEncoder(d_model*3, n_heads, d_ff*3, n_layers)

        self.fftfusion = FilterLayer(fft_ratio,int(d_model*3),int(d_model) )
        self.MLP_all_fft = nn.Sequential(
            nn.Linear(d_model*3, d_model*3)
        )


        self.MLP_X = nn.Sequential(
            nn.Linear(d_model, d_model)
        )
        self.MLP_T = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.MLP_I = nn.Sequential(
            nn.Linear(d_model, d_model)
        )

        self.MLP_all = nn.Sequential(
            nn.Linear(d_model*3, 32)
        )

        self.ALL3 = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.feature_dim = feature_num
        hidden_dim = 32
        self.cluster_num = 7
        self.instance_projector = nn.Sequential(
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.feature_dim),
        )
        self.cluster_projector = nn.Sequential(
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.cluster_num),
        )

        self.cluster_projector_all = nn.Sequential(
            nn.BatchNorm1d(hidden_dim*3),
            nn.ReLU(),
            nn.Linear(hidden_dim*3, hidden_dim*3),
            nn.BatchNorm1d(hidden_dim*3),
            nn.ReLU(),
            nn.Linear(hidden_dim*3, self.cluster_num),
        )


        # self.weight1 = nn.Parameter(torch.ones(1))
        # self.weight2 = nn.Parameter(torch.ones(1))
        # self.weight3 = nn.Parameter(torch.ones(1))
        # ###################### 新增MoE组件 ######################
        # self.num_experts = 4  # 每个模态的专家数量
        # self.top_k = 2        # 激活的专家数
        
        # # # 模态专属专家定义
        # self.moe_experts_ALL = nn.ModuleList([
        #     nn.Sequential(
        #         nn.Linear(d_model*3, 12*d_model),
        #         nn.GELU(),
        #         nn.Linear(12*d_model, d_model*3)
        #     ) for _ in range(self.num_experts)])
        # self.modal_gate = DynamicModalGate(feature_dim=32)  # 假设特征维度128
        
        
        # 动态路由网络
        # self.router_ALL = nn.Sequential(
        #     nn.Linear(d_model*3, d_model*3*3),
        #     nn.GELU(),
        #     nn.Linear( d_model*3*3, self.num_experts)
        # )

        #  # MoE Routing for each modality (x, i, t) with better weight computation
        # self.router_x = nn.Linear(d_model, 1)
        # self.router_i = nn.Linear(d_model, 1)
        # self.router_t = nn.Linear(d_model, 1)
        # # 专家负载记录（用于平衡损失）
        # # self.register_buffer('expert_counts_X', torch.zeros(self.num_experts))
        # # self.register_buffer('expert_counts_I', torch.zeros(self.num_experts))
        # self.register_buffer('expert_counts_ALL', torch.zeros(self.num_experts))
        
    def _moe_forward(self, x, experts, router, expert_counts):
        """
        MoE前向计算
        x: 输入特征 [batch_size, d_model]
        experts: 专家列表
        router: 路由网络
        expert_counts: 专家调用计数器
        """
        # 计算路由权重
        gate_logits = router(x)  # [batch_size, num_experts]
        gate = torch.softmax(gate_logits, dim=-1)
        
        # 选择top-k专家
        top_k_weights, top_k_indices = torch.topk(gate, self.top_k, dim=-1)  # [B, top_k]
        
        # 创建稀疏掩码
        mask = torch.zeros_like(gate).scatter(1, top_k_indices, 1)
        masked_gate = gate * mask
        
        # 归一化权重
        norm_weights = masked_gate / (masked_gate.sum(dim=1, keepdim=True) + 1e-6)
        expert_outputs = torch.zeros_like(x)  # 初始化输出张量，形状为 [B, d_model]
            # 专家计算
        for i in range(self.num_experts):
            # 获取当前专家的样本索引
            idx = (top_k_indices == i)  # [B, top_k]
            
            # 如果该专家被选中
            if idx.any(dim=1).any():  # 只考虑有样本被路由到当前专家的情况
                # 获取路由到当前专家的输入样本
                expert_input = x[idx.any(dim=1)]  # 选择被路由到该专家的样本 [num_samples, d_model]
                
                # 获取专家的输出 [num_samples, d_model]
                expert_out = experts[i](expert_input)
                
                # 获取专家对应的权重
                weight = norm_weights[idx.any(dim=1), i].unsqueeze(1)  # [num_samples, 1]
                
                # 将加权的专家输出添加到总输出中
                expert_outputs[idx.any(dim=1)] += expert_out * weight  # [num_samples, d_model] * [num_samples, 1] -> [num_samples, d_model]

                # 更新专家调用计数
                expert_counts[i] += idx.any(dim=1).sum().item()
        
        return expert_outputs

    def forward(self, x):
        # 原始特征提取
        x, i, t = torch.split(x, [self.nfeatX, self.nfeatI,self.nfeatT], dim=1)


        zero_x = torch.zeros_like(x)
        zero_i = torch.zeros_like(i)
        zero_t = torch.zeros_like(t)
        emb_x = self.GCN_G(x, self.sadj)
        emb_i = self.GCN_A(i, self.sadj)
        emb_t = self.GCN_T(t, self.sadj)


        # fadj mei yong 
        ###################### MoE增强特征 ######################
        # 对每个模态进行专家增强


        emb1_x = emb_x
        emb2_i = emb_i
        emb3_t = emb_t

# # Step 3: MOE Routing for each modality (x, i, t)
#         weight_x = self.router_x(emb_x)
#         weight_i = self.router_i(emb_i)
#         weight_t = self.router_t(emb_t)

#         # Apply softmax to the weights
#         weight_x = torch.softmax(weight_x, dim=-1)
#         weight_i = torch.softmax(weight_i, dim=-1)
#         weight_t = torch.softmax(weight_t, dim=-1)

#         # Expert combination using MOE mechanism with attention for better fusion
#         weighted_x = weight_x * emb_x
#         weighted_i = weight_i * emb_i
#         weighted_t = weight_t * emb_t

#         emb1_x = self.weight1 * emb1_x 
#         emb2_i = self.weight2 * emb2_i 
#         emb3_t = self.weight3 * emb3_t

        all_emb = torch.cat([emb1_x,emb2_i, emb3_t], dim=1)

        # weight_x = 1.0
        # weight_i = 0.00001  # 给 i 模态较低的权重
        # weight_t = 1.0
        # # 加权求和
        # all_emb = weight_x * emb_x + weight_i * emb_i + weight_t * emb_t
        # all_emb = self.ALL3(all_emb)

        # all_emb_t = self._moe_forward(
        #     self.transformer_all(all_emb), 
        #     self.moe_experts_ALL, 
        #     self.router_ALL,
        #     self.expert_counts_ALL)
        
        all_emb_t = self.transformer_all(all_emb)
        all_emb_pesodu = self.fftfusion(all_emb_t)


        q_x = self.MLP_X (emb_x)
        q_i = self.MLP_I (emb_x)
        q_t = self.MLP_T (all_emb_t)
        # q_x =emb1_x
        # q_i = emb2_i
        # q_t = emb3_t

        all_emb_xti = self.MLP_all(all_emb_t)

        [pi, disp, mean]  = self.ZINB(emb1_x)

        # [pi, disp, mean]  = self.ZINB(emb1_x)
        z_i = F.normalize(self.instance_projector(emb1_x), dim=1)
        z_j = F.normalize(self.instance_projector(emb2_i), dim=1)
        z_k = F.normalize(self.instance_projector(emb3_t), dim=1)
        z_xti = F.normalize(self.instance_projector(all_emb_xti), dim=1)

        c_xti = self.cluster_projector_all(all_emb_pesodu)
        c_i = self.cluster_projector(emb1_x)
        c_j = self.cluster_projector(emb2_i)
        c_k = self.cluster_projector(emb3_t)
        _ = 0
        # return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t, _,_,_,_,_,_,_,_
        return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j,z_xti,c_xti,z_k,c_k


# class stMMR(nn.Module):
#     def __init__(self,nfeatX,nfeatI,nfeatT, hidden_dims,fft_ratio,feature_num):
#         super(stMMR, self).__init__()


#         dropout = 0.
#         self.GCN_G = GCN(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
#         self.GCN_A = GCN(nfeatI, hidden_dims[0], hidden_dims[1], dropout)
#         self.GCN_T = GCN(nfeatT, hidden_dims[0], hidden_dims[1], dropout)


#         self.fc = nn.Linear(hidden_dims[1]*3, hidden_dims[1])
#         self.ZINB = decoder(hidden_dims[1],nfeatX)
#         # self.ZINB_T = decoder(hidden_dims[1],nfeatT)

#         d_model = hidden_dims[1]
#         n_heads = 4
#         d_ff = hidden_dims[1]*4
#         n_layers = 2
#         # # Create TransformerEncoder model
#         self.transformer = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
#         self.transformer_2 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
#         self.transformer_3 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)

#         self.transformer_all = TransformerEncoder(d_model*3, n_heads, d_ff*3, n_layers)

#         self.fftfusion = FilterLayer(fft_ratio,int(d_model*3),int(d_model) )
#         self.MLP_all_fft = nn.Sequential(
#             nn.Linear(d_model*3, d_model*3)
#         )


#         self.MLP_X = nn.Sequential(
#             nn.Linear(d_model*3, d_model)
#         )
#         self.MLP_T = nn.Sequential(
#             nn.Linear(d_model*3, d_model)
#         )

#         self.MLP_I = nn.Sequential(
#             nn.Linear(d_model*3, d_model)
#         )

#         self.MLP_all = nn.Sequential(
#             nn.Linear(d_model*3, 32)
#         )

#         self.feature_dim = feature_num
#         hidden_dim = 32
#         self.cluster_num = 7
#         self.instance_projector = nn.Sequential(
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#             nn.Linear(hidden_dim, hidden_dim),
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#             nn.Linear(hidden_dim, self.feature_dim),
#         )
#         self.cluster_projector = nn.Sequential(
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#             nn.Linear(hidden_dim, hidden_dim),
#             nn.BatchNorm1d(hidden_dim),
#             nn.ReLU(),
#             nn.Linear(hidden_dim, self.cluster_num),
#         )

#         self.cluster_projector_all = nn.Sequential(
#             nn.BatchNorm1d(hidden_dim*3),
#             nn.ReLU(),
#             nn.Linear(hidden_dim*3, hidden_dim*3),
#             nn.BatchNorm1d(hidden_dim*3),
#             nn.ReLU(),
#             nn.Linear(hidden_dim*3, self.cluster_num),
#         )


#     def forward(self,x,i, t ,fadj,sadj):


#         # t = torch.cat([x, t], dim=1)

#         emb_x = self.GCN_G(x, fadj)
#         emb_i = self.GCN_A(i, sadj)
#         emb_t = self.GCN_T(t, fadj)


        
#         ## attention for omics specific information of scRNA-seq
#         emb1_x =  self.transformer(emb_x)
#         emb2_i =  self.transformer_2(emb_i)
#         emb3_t =  self.transformer_3(emb_t)
        
#         # emb1_x = emb_x
#         # emb2_i = emb_i 
#         # emb3_t = emb_t 

#         all_emb = torch.cat([emb1_x, emb2_i, emb3_t], dim=1)

#         all_emb_t = self.transformer_all(all_emb)


#         # x = self.fftfusion(x)


#         # n_x, n_t, n_i = emb1_x.shape[1], emb3_t.shape[1], emb2_i.shape[1]
#         # 使用torch.split分开all_emb
#         # split_size = [n_x, n_t, n_i]  # 特征分割的大小
#         # q_x, q_t, q_i = torch.split(all_emb_t, split_size, dim=1)
         
#         all_emb_pesodu = self.fftfusion(all_emb_t)


#         q_x = self.MLP_X (all_emb_t)
#         q_i = self.MLP_I (all_emb_t)
#         q_t = self.MLP_T (all_emb_t)


#         all_emb_xti = self.MLP_all(all_emb_t)

#         [pi, disp, mean]  = self.ZINB(q_x)


#         z_i = F.normalize(self.instance_projector(emb1_x), dim=1)
#         z_j = F.normalize(self.instance_projector(emb2_i), dim=1)
#         z_k = F.normalize(self.instance_projector(emb3_t), dim=1)
#         z_xti = F.normalize(self.instance_projector(all_emb_xti), dim=1)

#         c_xti = self.cluster_projector_all(all_emb_pesodu)
#         c_i = self.cluster_projector(emb1_x)
#         c_j = self.cluster_projector(emb2_i)
#         c_k = self.cluster_projector(emb3_t)


#         return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j,z_xti,c_xti,z_k,c_k



class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attention = nn.MultiheadAttention(d_model, n_heads, dropout=dropout)
        self.feedforward = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Linear(d_ff, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attn_output, _ = self.self_attention(x, x, x)
        attn_output = self.norm1(attn_output + x)
        ff_output = self.feedforward(attn_output)
        return self.norm2(ff_output + attn_output)

class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, n_layers, dropout=0.1):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([TransformerEncoderLayer(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
    


class FilterLayer(nn.Module):
    def __init__(self,fft_ratio ,max_input_length: int, hidden_dim: int):
        super(FilterLayer, self).__init__()

        self.max_input_length = max_input_length
        self.fft_ratio = fft_ratio
        # 初始化可训练的复数权重
        # self.complex_weight = nn.Parameter(torch.randn(self.max_input_length // 2 + 1, hidden_dim, 2, dtype=torch.float32))

        # Dropout层
        self.Dropout = nn.Dropout(0.1)

    def forward(self, input_tensor: torch.Tensor):
        # 获取输入的细胞数 (x) 和基因数 (y)
        x, y = input_tensor.shape

        # 执行FFT（正向傅里叶变换）
        # 这里 n=self.max_input_length 让我们控制傅里叶变换后的长度
        x_fft = torch.fft.rfft(input_tensor, n=self.max_input_length, dim=1, norm='forward')

        num_frequencies = x_fft.shape[1]
        k = int (num_frequencies * self.fft_ratio  )  # 保留50%的低频成分

        # 选择低频部分
        x_fft_low = x_fft[:, :k]  # 保留前k个频率成分
        # 使用复数权重进行调整
        # weight = torch.view_as_complex(self.complex_weight)
        # x_fft = torch.matmul( x_fft, weight)

        # 执行反傅里叶变换（恢复到时域）
        sequence_emb_fft = torch.fft.irfft(x_fft_low, n=self.max_input_length, dim=1, norm='forward')

        # 调整输出的尺寸，确保与原输入序列长度匹配
        sequence_emb_fft = sequence_emb_fft[:, :y]

        hidden_states = sequence_emb_fft
        # Dropout操作
        # sequence_emb_fft = self.Dropout(sequence_emb_fft)

        # 将处理后的结果与输入相加
        # hidden_states = sequence_emb_fft + input_tensor

        return hidden_states
    

    
class DynamicModalGate(nn.Module):
    def __init__(self, feature_dim):
        super().__init__()
        # 门控参数生成器
        self.gate_net = nn.Sequential(
            nn.Linear(feature_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid()  # 输出0-1的门控值
        )
        
    def forward(self, features):
        # features: 各模态特征列表 [emb_x, emb_i, emb_t]
        gate_values = [self.gate_net(feat) for feat in features]
        weighted_features = [feat * gate for feat, gate in zip(features, gate_values)]
        return weighted_features, gate_values