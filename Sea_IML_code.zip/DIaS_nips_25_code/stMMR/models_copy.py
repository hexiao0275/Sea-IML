import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from sklearn.cluster import KMeans
import torch.optim as optim
from random import shuffle
import pandas as pd
import numpy as np
import scanpy as sc
from stMMR.layers import GraphConvolution,SelfAttention,MLP,MGCN,decoder
import sys

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, out)
        self.dropout = dropout
    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x

class stMMR(nn.Module):
    def __init__(self,nfeatX,nfeatI,nfeatT, hidden_dims):
        super(stMMR, self).__init__()


        dropout = 0.
        self.GCN_G = GCN(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_A = GCN(nfeatI, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_T = GCN(nfeatT+nfeatX, hidden_dims[0], hidden_dims[1], dropout)


        self.fc = nn.Linear(hidden_dims[1]*3, hidden_dims[1])
        self.ZINB = decoder(hidden_dims[1],nfeatX)
        # self.ZINB_T = decoder(hidden_dims[1],nfeatT)

        d_model = hidden_dims[1]
        n_heads = 4
        d_ff = hidden_dims[1]*4
        n_layers = 2
        # # Create TransformerEncoder model
        # self.transformer = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        # self.transformer_2 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        # self.transformer_3 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)

        self.transformer_all = TransformerEncoder(d_model*3, n_heads, d_ff*3, n_layers)

        self.MLP_X = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )
        self.MLP_T = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.MLP_I = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.MLP_all = nn.Sequential(
            nn.Linear(d_model*3, 32)
        )


    def forward(self,x,i, t ,fadj,sadj):
    

        t = torch.cat([x, t], dim=1)

        emb_x = self.GCN_G(x, fadj)
        emb_i = self.GCN_A(i, sadj)
        emb_t = self.GCN_T(t, fadj)
        ## attention for omics specific information of scRNA-seq

        # emb1_x = emb_x + self.transformer(emb_x)
        # emb2_i = emb_i +  self.transformer_2(emb_i)
        # emb3_t = emb_t + self.transformer_3(emb_t)
        emb1_x = emb_x
        emb2_i = emb_i 
        emb3_t = emb_t 

        all_emb = torch.cat([emb1_x, emb2_i, emb3_t], dim=1)
        all_emb_t = self.transformer_all(all_emb)

        # n_x, n_t, n_i = emb1_x.shape[1], emb3_t.shape[1], emb2_i.shape[1]
        # 使用torch.split分开all_emb
        # split_size = [n_x, n_t, n_i]  # 特征分割的大小
        # q_x, q_t, q_i = torch.split(all_emb_t, split_size, dim=1)

        q_x = self.MLP_X (all_emb_t)
        q_i = self.MLP_I (all_emb_t)
        q_t = self.MLP_T (all_emb_t)


        all_emb_xti = self.MLP_all(all_emb_t)

        [pi, disp, mean]  = self.ZINB(q_x)
        

        return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t



class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attention = nn.MultiheadAttention(d_model, n_heads, dropout=dropout)
        self.feedforward = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Linear(d_ff, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attn_output, _ = self.self_attention(x, x, x)
        attn_output = self.norm1(attn_output + x)
        ff_output = self.feedforward(attn_output)
        return self.norm2(ff_output + attn_output)

class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, n_layers, dropout=0.1):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([TransformerEncoderLayer(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
    
