import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
from sklearn.cluster import KMeans
import torch.optim as optim
from random import shuffle
import pandas as pd
import numpy as np
import scanpy as sc
from stMMR.layers import GraphConvolution,SelfAttention,MLP,MGCN,decoder
import sys
from scvi.models.modules import Encoder  # 注意是 module (单数) 不是 modules
import scvi
from stMMR.spaVAE.SVGP_yuan import SVGP
from torch.distributions import Normal
from torch.distributions import kl_divergence as kl
from torch.distributions import kl_divergence
from sklearn.preprocessing import MinMaxScaler

def gauss_cross_entropy(mu1, var1, mu2, var2):
    """
    Computes the element-wise cross entropy
    Given q(z) ~ N(z| mu1, var1)
    returns E_q[ log N(z| mu2, var2) ]
    args:
        mu1:  mean of expectation (batch, tmax, 2) tf variable
        var1: var  of expectation (batch, tmax, 2) tf variable
        mu2:  mean of integrand (batch, tmax, 2) tf variable
        var2: var of integrand (batch, tmax, 2) tf variable
    returns:
        cross_entropy: (batch, tmax, 2) tf variable
    """

    term0 = 1.8378770664093453  # log(2*pi)
    epsilon = 1e-7  # 更小的 epsilon
    var2 = torch.clamp(var2, min=epsilon)
    term1 = torch.log(var2 )
    term2 = (var1 + mu1 ** 2 - 2 * mu1 * mu2 + mu2 ** 2) / var2

    cross_entropy = -0.5 * (term0 + term1 + term2)

    return cross_entropy



def calculate_gp_gn_elbo(z_dim,svgp_instance, qz_m_half, qz_v_half, pos_2d_1, b):
    # 从 qz_m 和 qz_v 中提取目标部分

    gp_mu = qz_m_half[:, 0:z_dim]
    gp_var = qz_v_half[:, 0:z_dim]

    gaussian_mu = qz_m_half[:, z_dim:]
    gaussian_var = qz_v_half[:, z_dim:]

    inside_elbo_recon, inside_elbo_kl = [], []
    gp_p_m, gp_p_v = [], []

    for l in range(z_dim):
        gp_p_m_l, gp_p_v_l, mu_hat_l, A_hat_l = svgp_instance.approximate_posterior_params(pos_2d_1, pos_2d_1,
                                                                gp_mu[:, l], gp_var[:, l])
        inside_elbo_recon_l,  inside_elbo_kl_l = svgp_instance.variational_loss(x=pos_2d_1, y=gp_mu[:, l],
                                                                noise=gp_var[:, l], mu_hat=mu_hat_l,
                                                                A_hat=A_hat_l)
        
        inside_elbo_recon.append(inside_elbo_recon_l)
        inside_elbo_kl.append(inside_elbo_kl_l)
        gp_p_m.append(gp_p_m_l)
        gp_p_v.append(gp_p_v_l)

    inside_elbo_recon = torch.stack(inside_elbo_recon, dim=-1)
    inside_elbo_kl = torch.stack(inside_elbo_kl, dim=-1)
    inside_elbo_recon = torch.sum(inside_elbo_recon)
    inside_elbo_kl = torch.sum(inside_elbo_kl)

    inside_elbo = inside_elbo_recon - (b / svgp_instance.N_train) * inside_elbo_kl

    gp_p_m = torch.stack(gp_p_m, dim=1)
    gp_p_v = torch.stack(gp_p_v, dim=1)

    # cross entropy term
    gp_ce_term = gauss_cross_entropy(gp_p_m, gp_p_v, gp_mu, gp_var)
    gp_ce_term = torch.sum(gp_ce_term)

    # KL term of GP prior
    gp_KL_term = gp_ce_term - inside_elbo

    # KL term of Gaussian prior
    gaussian_prior_dist = Normal(torch.zeros_like(gaussian_mu), torch.ones_like(gaussian_var))
    gaussian_post_dist = Normal(gaussian_mu, torch.sqrt(gaussian_var))

    gaussian_KL_term = kl_divergence(gaussian_post_dist, gaussian_prior_dist).sum()
    # ELBO
    elbo_s_t = gp_KL_term + gaussian_KL_term

    sample_all = torch.cat((gp_p_m, gaussian_mu), dim=1)
    return elbo_s_t, gp_KL_term, gaussian_KL_term, sample_all, gp_p_m , gaussian_mu


def buildNetwork(layers, network="decoder", activation="relu", dropout=0., dtype=torch.float32, norm="batchnorm"):
    net = []
    if network == "encoder" and dropout > 0:
        net.append(nn.Dropout(p=dropout))
    for i in range(1, len(layers)):
        net.append(nn.Linear(layers[i-1], layers[i]))
        if norm == "batchnorm":
            net.append(nn.BatchNorm1d(layers[i]))
        elif norm == "layernorm":
            net.append(nn.LayerNorm(layers[i]))
        if activation=="relu":
            net.append(nn.ReLU())
        elif activation=="sigmoid":
            net.append(nn.Sigmoid())
        elif activation=="elu":
            net.append(nn.ELU())
        if dropout > 0:
            net.append(nn.Dropout(p=dropout))
    return nn.Sequential(*net)

class DenseEncoder(nn.Module):
    def __init__(self, input_dim, hidden_dims, output_dim, activation="relu", dropout=0, dtype=torch.float32, norm="batchnorm"):
        super(DenseEncoder, self).__init__()
        self.layers = buildNetwork([input_dim]+hidden_dims, network="decoder", activation=activation, dropout=dropout, dtype=dtype, norm=norm)
        self.enc_mu = nn.Linear(hidden_dims[-1], output_dim)
        self.enc_var = nn.Linear(hidden_dims[-1], output_dim)

    def forward(self, x):
        h = self.layers(x)
        mu = self.enc_mu(h)
        var = torch.exp(self.enc_var(h).clamp(-15, 15))

        log_noise_sum = torch.sum(torch.log(var))
        if torch.isnan(log_noise_sum).any():
            print("noise 中存在 NaN")

        return mu, var

class GCN(nn.Module):
    def __init__(self, nfeat, nhid, out, dropout):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, out)
        self.dropout = dropout
    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = self.gc2(x, adj)
        return x


class MLP(nn.Module):
    def __init__(self, input_dim, hidden_dim1, hidden_dim2, dropout):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim1)
        self.fc2 = nn.Linear(hidden_dim1, hidden_dim2)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        return x
    
class stMMR(nn.Module):
    def __init__(self,nfeatX,nfeatI,nfeatT, hidden_dims,fft_ratio,feature_num,sadj,fadj):
        super(stMMR, self).__init__()

        self.encoder_1 = DenseEncoder(input_dim=nfeatX, hidden_dims=[hidden_dims[0]], output_dim=hidden_dims[1]*2, activation="elu", dropout=0.1)

        zero_cat_list = [int(0)]
        self.encoder_2 = Encoder(
            n_input=nfeatX, 
            n_output=hidden_dims[1],  # 修正为n_output
            n_hidden=hidden_dims[0],
            n_cat_list=zero_cat_list,
            distribution="normal",
            dropout_rate=0.1,
            # use_batch_norm=True,
            # use_layer_norm=False,
            # var_activation=None,
        )

        self.sadj =sadj
        self.fadj =fadj
        dropout = 0.1
        self.nfeatX = nfeatX
        self.nfeatI = nfeatI
        self.nfeatT = nfeatT
        self.GCN_G = GCN(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_A = GCN(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        self.GCN_T = GCN(nfeatT, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_G = MLP(nfeatX, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_A = MLP(nfeatI, hidden_dims[0], hidden_dims[1], dropout)
        # self.GCN_T = MLP(nfeatT, hidden_dims[0], hidden_dims[1], dropout)

        self.fc = nn.Linear(hidden_dims[1]*3, hidden_dims[1])
        self.ZINB = decoder(hidden_dims[1],nfeatX)
        # self.ZINB_T = decoder(hidden_dims[1],nfeatT)

        d_model = hidden_dims[1]
        n_heads = 2
        d_ff = hidden_dims[1]*2
        n_layers = 1
        # # Create TransformerEncoder model
        self.transformer = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        self.transformer_2 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)
        self.transformer_3 = TransformerEncoder(d_model, n_heads, d_ff, n_layers)

        self.transformer_all = TransformerEncoder(d_model, n_heads, d_ff, n_layers)

        self.fftfusion = FilterLayer(fft_ratio,int(d_model),int(d_model) )
        self.MLP_all_fft = nn.Sequential(
            nn.Linear(d_model*3, d_model*3)
        )

        loc_range = 20.
        kernel_scale = 20.
        eps = 1e-5
        inducing_point_steps = 5
        initial_inducing_points = np.mgrid[0:(1+eps):(1./inducing_point_steps), 0:(1+eps):(1./inducing_point_steps)].reshape(2, -1).T * loc_range
        print(initial_inducing_points.shape)
        # 假设你已经定义了 device
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.ssvgp_loss = SVGP(fixed_inducing_points=True, initial_inducing_points=initial_inducing_points,
        fixed_gp_params=False, kernel_scale=kernel_scale, jitter=1e-8, N_train=feature_num, dtype=torch.float64, device=device)
        

        self.MLP_X = nn.Sequential(
            nn.Linear(d_model, d_model)
        )
        self.MLP_T = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.MLP_I = nn.Sequential(
            nn.Linear(d_model, d_model)
        )

        self.MLP_all = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.ALL3 = nn.Sequential(
            nn.Linear(d_model*3, d_model)
        )

        self.feature_dim = feature_num
        hidden_dim = d_model
        self.cluster_num = 7
        self.instance_projector = nn.Sequential(
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.feature_dim),
        )
        self.cluster_projector = nn.Sequential(
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.cluster_num),
        )

        self.cluster_projector_all = nn.Sequential(
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, self.cluster_num),
        )



    def forward(self, x,loc):
        # 原始特征提取
        x, i, t = torch.split(x, [self.nfeatX, self.nfeatI,self.nfeatT], dim=1)

        i = x
        emb_x = self.GCN_G(x, self.sadj)
        emb_i = self.GCN_A(i, self.sadj)
        emb_t = self.GCN_T(t, self.sadj)

        # emb_i_qnet_mu = 0
        # emb_i_qnet_var=0
        # elbo_z_t=0
        
        # batch_size = i.shape[0]
        # dummy_batch = torch.zeros(batch_size, dtype=torch.long, device=x.device)
        # cat_list = (dummy_batch,)
        # # 获取编码器的输出，确保解包与返回值匹配
        # emb_i, emb_i_qnet_mu, emb_i_qnet_var  = self.encoder_2(i,*cat_list) 
        # emb_i_qnet_mu = 0
        # emb_i_qnet_var = 0
        emb_i_qnet_mu, emb_i_qnet_var = self.encoder_1(i)
        emb_i_qnet_mu = emb_i_qnet_mu.double()
        emb_i_qnet_var = emb_i_qnet_var.double()
        loc = loc.double()

        b = x.shape[0]  # 获取 batch 样本量
        out_dim = emb_x.shape[1]  # 获取 batch 样本量
        z_dim = out_dim
        # elbo_z_t , gp_KL_term_z_t, gaussian_KL_term_z_t, sample_all_i,  gp_p_m , gaussian_mu= calculate_gp_gn_elbo(z_dim,self.ssvgp_loss, emb_i_qnet_mu, emb_i_qnet_var, loc, b)
        elbo_z_t = 0.
        # emb_i = gp_p_m.float()
        # emb_t = gaussian_mu.float()

        emb1_x = emb_x
        emb2_i = emb_i
        emb3_t = emb_t

        all_emb = emb1_x
        # all_emb_t = self.transformer_all(all_emb)
        all_emb_t = all_emb
        all_emb_pesodu = self.fftfusion(all_emb_t)

        q_x = emb_x
        q_i = emb_i
        q_t = emb_t


        all_emb_xti = all_emb_t

        [pi, disp, mean]  = self.ZINB(all_emb_xti)
        _ = 0
        # [pi, disp, mean]  = self.ZINB(emb1_x)
        z_i = _
        z_j = _
        z_k = _
        z_xti = _

        c_xti = _
        c_i = _
        c_j = _
        c_k = _

        # return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t, _,_,_,_,_,_,_,_
        return all_emb_xti, q_x, q_i, q_t,  pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j,z_xti,c_xti,z_k,c_k \
              , emb_i_qnet_mu, emb_i_qnet_var, elbo_z_t





class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, dropout=0.1):
        super(TransformerEncoderLayer, self).__init__()
        self.self_attention = nn.MultiheadAttention(d_model, n_heads, dropout=dropout)
        self.feedforward = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.ReLU(),
            nn.Linear(d_ff, d_model)
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        attn_output, _ = self.self_attention(x, x, x)
        attn_output = self.norm1(attn_output + x)
        ff_output = self.feedforward(attn_output)
        return self.norm2(ff_output + attn_output)

class TransformerEncoder(nn.Module):
    def __init__(self, d_model, n_heads, d_ff, n_layers, dropout=0.1):
        super(TransformerEncoder, self).__init__()
        self.layers = nn.ModuleList([TransformerEncoderLayer(d_model, n_heads, d_ff, dropout) for _ in range(n_layers)])

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x
    


class FilterLayer(nn.Module):
    def __init__(self,fft_ratio ,max_input_length: int, hidden_dim: int):
        super(FilterLayer, self).__init__()

        self.max_input_length = max_input_length
        self.fft_ratio = fft_ratio
        # 初始化可训练的复数权重
        # self.complex_weight = nn.Parameter(torch.randn(self.max_input_length // 2 + 1, hidden_dim, 2, dtype=torch.float32))

        # Dropout层
        self.Dropout = nn.Dropout(0.1)

    def forward(self, input_tensor: torch.Tensor):
        # 获取输入的细胞数 (x) 和基因数 (y)
        x, y = input_tensor.shape

        # 执行FFT（正向傅里叶变换）
        # 这里 n=self.max_input_length 让我们控制傅里叶变换后的长度
        x_fft = torch.fft.rfft(input_tensor, n=self.max_input_length, dim=1, norm='forward')

        num_frequencies = x_fft.shape[1]
        k = int (num_frequencies * self.fft_ratio  )  # 保留50%的低频成分

        # 选择低频部分
        x_fft_low = x_fft[:, :k]  # 保留前k个频率成分
        # 使用复数权重进行调整
        # weight = torch.view_as_complex(self.complex_weight)
        # x_fft = torch.matmul( x_fft, weight)

        # 执行反傅里叶变换（恢复到时域）
        sequence_emb_fft = torch.fft.irfft(x_fft_low, n=self.max_input_length, dim=1, norm='forward')

        # 调整输出的尺寸，确保与原输入序列长度匹配
        sequence_emb_fft = sequence_emb_fft[:, :y]

        hidden_states = sequence_emb_fft
        # Dropout操作
        # sequence_emb_fft = self.Dropout(sequence_emb_fft)

        # 将处理后的结果与输入相加
        # hidden_states = sequence_emb_fft + input_tensor

        return hidden_states
    

    
class DynamicModalGate(nn.Module):
    def __init__(self, feature_dim):
        super().__init__()
        # 门控参数生成器
        self.gate_net = nn.Sequential(
            nn.Linear(feature_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 1),
            nn.Sigmoid()  # 输出0-1的门控值
        )
        
    def forward(self, features):
        # features: 各模态特征列表 [emb_x, emb_i, emb_t]
        gate_values = [self.gate_net(feat) for feat in features]
        weighted_features = [feat * gate for feat, gate in zip(features, gate_values)]
        return weighted_features, gate_values