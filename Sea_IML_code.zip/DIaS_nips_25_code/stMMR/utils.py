import numpy as np
import numba
import scanpy as sc
from munkres import Munkres
from collections import Counter
import torch
import sys
import ot
import torch.nn as nn
import torch.nn.functional as F
import diffdist
import torch.distributed as dist
# import pandas as pd

@numba.njit("f4(f4[:], f4[:])")
def euclid_dist(t1,t2):
    sum=0
    for i in range(t1.shape[0]):
        sum+=(t1[i]-t2[i])**2
    return np.sqrt(sum)

@numba.njit("f4[:,:](f4[:,:])", parallel=True, nogil=True)
def pairwise_distance(X):
    n=X.shape[0]
    adj=np.empty((n, n), dtype=np.float32)
    for i in numba.prange(n):
        for j in numba.prange(n):
            adj[i][j]=euclid_dist(X[i], X[j])
    return adj

def calculate_adj_matrix(adata):
    x = adata.obs["array_row"]
    y = adata.obs["array_col"]
    X=np.array([x, y]).T.astype(np.float32)
    adj = pairwise_distance(X)
    return adj

def _nan2zero(x):
    return torch.where(torch.isnan(x), torch.zeros_like(x), x)

def _nan2inf(x):
    return torch.where(torch.isnan(x), torch.zeros_like(x) + np.inf, x)
class NB(object):
    def __init__(self, theta=None, scale_factor=1.0):
        super(NB, self).__init__()
        self.eps = 1e-10
        self.scale_factor = scale_factor
        self.theta = theta

    def loss(self, y_true, y_pred, mean=True):
        y_pred = y_pred * self.scale_factor
        theta = torch.minimum(self.theta, torch.tensor(1e6))
        t1 = torch.lgamma(theta + self.eps) + torch.lgamma(y_true + 1.0) - torch.lgamma(y_true + theta + self.eps)
        t2 = (theta + y_true) * torch.log(1.0 + (y_pred / (theta + self.eps))) + (
                y_true * (torch.log(theta + self.eps) - torch.log(y_pred + self.eps)))
        final = t1 + t2
        final = _nan2inf(final)
        if mean:
            final = torch.mean(final)
        return final


class ZINB(NB):
    def __init__(self, pi, ridge_lambda=0.0, **kwargs):
        super().__init__(**kwargs)
        self.pi = pi
        self.ridge_lambda = ridge_lambda

    def loss(self, y_true, y_pred, mean=True):
        scale_factor = self.scale_factor
        eps = self.eps
        theta = torch.minimum(self.theta, torch.tensor(1e6))
        nb_case = super().loss(y_true, y_pred, mean=False) - torch.log(1.0 - self.pi + eps)
        y_pred = y_pred * scale_factor
        zero_nb = torch.pow(theta / (theta + y_pred + eps), theta)
        zero_case = -torch.log(self.pi + ((1.0 - self.pi) * zero_nb) + eps)
        result = torch.where(torch.lt(y_true, 1e-8), zero_case, nb_case)
        ridge = self.ridge_lambda * torch.square(self.pi)
        result += ridge
        if mean:
            result = torch.mean(result)
        result = _nan2inf(result)
        return result

def compute_joint(view1, view2):
    """Compute the joint probability matrix P"""

    bn, k = view1.size()
    assert (view2.size(0) == bn and view2.size(1) == k)

    p_i_j = view1.unsqueeze(2) * view2.unsqueeze(1)
    p_i_j = p_i_j.sum(dim=0)
    p_i_j = (p_i_j + p_i_j.t()) / 2.  # symmetrise
    p_i_j = p_i_j / p_i_j.sum()  # normalise

    return p_i_j

def consistency_loss(emb1, emb2):
    emb1 = emb1 - torch.mean(emb1, dim=0, keepdim=True)
    emb2 = emb2 - torch.mean(emb2, dim=0, keepdim=True)
    emb1 = torch.nn.functional.normalize(emb1, p=2, dim=1)
    emb2 = torch.nn.functional.normalize(emb2, p=2, dim=1)
    cov1 = torch.matmul(emb1, emb1.t())
    cov2 = torch.matmul(emb2, emb2.t())
    return torch.mean((cov1 - cov2) ** 2)

def crossview_contrastive_Loss(view1, view2, lamb=9.0, EPS=sys.float_info.epsilon):
    """Contrastive loss for maximizng the consistency"""
    _, k = view1.size()
    p_i_j = compute_joint(view1, view2)
    assert (p_i_j.size() == (k, k))

    p_i = p_i_j.sum(dim=1).view(k, 1).expand(k, k)
    p_j = p_i_j.sum(dim=0).view(1, k).expand(k, k)

    #     Works with pytorch <= 1.2
    #     p_i_j[(p_i_j < EPS).data] = EPS
    #     p_j[(p_j < EPS).data] = EPS
    #     p_i[(p_i < EPS).data] = EPS

    # Works with pytorch > 1.2
    p_i_j = torch.where(p_i_j < EPS, torch.tensor([EPS], device=p_i_j.device), p_i_j)
    p_j = torch.where(p_j < EPS, torch.tensor([EPS], device=p_j.device), p_j)
    p_i = torch.where(p_i < EPS, torch.tensor([EPS], device=p_i.device), p_i)

    loss = - p_i_j * (torch.log(p_i_j) \
                      - (lamb + 1) * torch.log(p_j) \
                      - (lamb + 1) * torch.log(p_i))

    loss = loss.sum()

    return loss*-1

def cosine_similarity(emb):
    mat = torch.matmul(emb, emb.T)
    norm = torch.norm(emb, p=2, dim=1).reshape((emb.shape[0], 1))
    mat = torch.div(mat, torch.matmul(norm, norm.T))
    if torch.any(torch.isnan(mat)):
        mat = _nan2zero(mat)
    mat = mat - torch.diag_embed(torch.diag(mat))
    return mat

def regularization_loss(emb, adj):
    mat = torch.sigmoid(cosine_similarity(emb))  # .cpu()
    loss = torch.mean((mat - adj) ** 2)
    return loss




def regularization_loss_graph_nei(emb, graph_nei, graph_neg):
    mat = torch.sigmoid(cosine_similarity(emb))  # .cpu()
    # mat = pd.DataFrame(mat.cpu().detach().numpy()).values

    # graph_neg = torch.ones(graph_nei.shape) - graph_nei

    neigh_loss = torch.mul(graph_nei, torch.log(mat)).mean()
    neg_loss = torch.mul(graph_neg, torch.log(1 - mat)).mean()
    pair_loss = -(neigh_loss + neg_loss) / 2
    return pair_loss

def refine_label(adata, radius=50, key='cluster'):
    n_neigh = radius
    new_type = []
    old_type = adata.obs[key].values

    # calculate distance
    position = adata.obsm['spatial']
    distance = ot.dist(position, position, metric='euclidean')
    n_cell = distance.shape[0]

    for i in range(n_cell):
        vec = distance[i, :]
        index = vec.argsort()
        neigh_type = []
        for j in range(1, n_neigh + 1):
            neigh_type.append(old_type[index[j]])
        max_type = max(neigh_type, key=neigh_type.count)
        new_type.append(max_type)

    new_type = [str(i) for i in list(new_type)]
    # adata.obs['label_refined'] = np.array(new_type)

    return new_type



def munkres_newlabel(y_true, y_pred):
    """\
     Kuhn-Munkres algorithm to achieve mapping from cluster labels to ground truth label

    Parameters
    ----------
    y_true
        ground truth label
    y_pred
        cluster labels

    Returns
    -------
    mapping label
    """
    y_true = y_true - np.min(y_true)
    l1 = list(set(y_true))
    numclass1 = len(l1)
    l2 = list(set(y_pred))
    numclass2 = len(l2)
    ind = 0
    if numclass1 != numclass2:
        for i in l1:
            if i in l2:
                pass
            else:
                y_pred[ind] = i
                ind += 1

    l2 = list(set(y_pred))
    numclass2 = len(l2)

    if numclass1 != numclass2:
        print('error')
        return 0,0,0

    cost = np.zeros((numclass1, numclass2), dtype=int)
    for i, c1 in enumerate(l1):
        mps = [i1 for i1, e1 in enumerate(y_true) if e1 == c1]
        for j, c2 in enumerate(l2):
            mps_d = [i1 for i1 in mps if y_pred[i1] == c2]
            cost[i][j] = len(mps_d)

    # match two clustering results by Munkres algorithm
    m = Munkres()
    cost = cost.__neg__().tolist()
    indexes = m.compute(cost)

    # get the match results
    new_predict = np.zeros(len(y_pred))
    for i, c in enumerate(l1):
        # correponding label in l2:
        c2 = l2[indexes[i][1]]

        # ai is the index with label==c2 in the pred_label list
        ai = [ind for ind, elm in enumerate(y_pred) if elm == c2]
        new_predict[ai] = c

    print('Counter(new_predict)\n', Counter(new_predict))
    print('Counter(y_true)\n', Counter(y_true))

    return new_predict


    
import torch



# 随机边丢失（Edge Dropout）
def random_edge_dropout(adj, dropout_rate):
    if not adj.is_sparse:
        raise ValueError("Input adjacency matrix must be a sparse tensor.")
    
    indices = adj._indices()
    values = adj._values()
    
    num_edges = values.size(0)
    dropout_mask = torch.rand(num_edges, device=adj.device) > dropout_rate
    new_indices = indices[:, dropout_mask]
    new_values = values[dropout_mask]
    
    new_adj = torch.sparse_coo_tensor(new_indices, new_values, size=adj.size(), device=adj.device)
    return new_adj

# 随机边添加（Edge Addition）
def random_edge_addition(adj, num_additions):
    if not adj.is_sparse:
        raise ValueError("Input adjacency matrix must be a sparse tensor.")
    
    indices = adj._indices().tolist()
    values = adj._values().tolist()
    
    num_nodes = adj.size(0)
    new_edges = 0
    
    while new_edges < num_additions:
        node1 = torch.randint(num_nodes, (1,), device=adj.device).item()
        node2 = torch.randint(num_nodes, (1,), device=adj.device).item()
        if node1 != node2 and (node1, node2) not in zip(indices[0], indices[1]):
            indices[0].append(node1)
            indices[1].append(node2)
            values.append(1)
            new_edges += 1
    
    new_indices = torch.tensor(indices, dtype=torch.long, device=adj.device)
    new_values = torch.tensor(values, dtype=torch.float32, device=adj.device)
    new_adj = torch.sparse_coo_tensor(new_indices, new_values, size=adj.size(), device=adj.device)
    return new_adj

# 添加噪声到特征（Add Noise to Features）
def add_noise_to_features(features, noise_level):
    noise = torch.normal(0, noise_level, features.size(), device=features.device)
    return features + noise

# 特征丢失（Feature Dropout）
def feature_dropout(features, dropout_rate):
    mask = torch.rand(features.size(1), device=features.device) > dropout_rate
    mask = mask.float()
    return features * mask

# 综合实现（Augment Graph）
def augment_graph(adj, edge_dropout_rate, num_edge_additions):
    adj = random_edge_dropout(adj, edge_dropout_rate)
    adj = random_edge_addition(adj, num_edge_additions)
    # features = add_noise_to_features(features, noise_level)
    # features = feature_dropout(features, feature_dropout_rate)
    return adj




def SimilarityLoss(emb, graph_nei):
    device = emb.device
    # Normalize embeddings
    emb_norm = F.normalize(emb, p=2, dim=1)

    # Compute cosine similarity matrix
    similarity_matrix = torch.mm(emb_norm, emb_norm.t())

    # similarity_matrix.fill_diagonal_(0)
    # id_tensor = torch.eye(graph_nei.shape[0], device=device)
    # graph_nei = graph_nei - id_tensor  # 去掉自连接

    # Get the similarity of neighboring nodes
    positive_mask = graph_nei.bool()
    positive_similarities = similarity_matrix[positive_mask]

    # Compute the mean of positive similarities
    pos_loss = -torch.mean(positive_similarities)

    # Get the similarity of non-neighboring nodes (negative samples)
    negative_mask = ~positive_mask
    negative_similarities = similarity_matrix[negative_mask]

    # Compute loss for negative samples to ensure they are sufficiently apart
    neg_loss = F.relu(-negative_similarities)  # Ensure negative samples are negative
    neg_loss = torch.mean(neg_loss)

    # Total loss
    # print(pos_loss)
    # print(neg_loss)
    total_loss = (1 + pos_loss) * 0.5 + neg_loss 
    return total_loss





class ClusterLoss(nn.Module):
    """
    Contrastive loss with distributed data parallel support
    """

    LARGE_NUMBER = 1e4

    def __init__(self, tau=1.0, multiplier=2, distributed=True):
        super().__init__()
        self.tau = tau
        self.multiplier = multiplier
        self.distributed = distributed

    def forward(self, c, get_map=False):
        n = c.shape[0]
        assert n % self.multiplier == 0

        c = F.normalize(c, p=2, dim=1) / np.sqrt(self.tau)

        logits = c @ c.t()
        logits[np.arange(n), np.arange(n)] = -self.LARGE_NUMBER

        # Non-distributed version: no need for diffdist or any distributed setup
        c_list = [torch.zeros_like(c)]  # No gathering, only a single list

        # Split into chunks based on the multiplier
        c_list = [chunk for chunk in c.chunk(self.multiplier)]

        # Sort the chunks (simply grouping them by multiplier, as there's no distributed sorting)
        c_sorted = []
        for m in range(self.multiplier):
            c_sorted.append(c_list[m])
        # Augment the data by splitting into two parts
        c_aug0 = torch.cat(c_sorted[:self.multiplier // 2], dim=0)
        c_aug1 = torch.cat(c_sorted[self.multiplier // 2:], dim=0)

        # Compute the probability distributions and entropy for both augmentations
        p_i = c_aug0.sum(0).view(-1)
        p_i /= p_i.sum()  # Normalize the probability distribution
        en_i = np.log(p_i.size(0)) + (p_i * torch.log(p_i)).sum()

        p_j = c_aug1.sum(0).view(-1)
        p_j /= p_j.sum()  # Normalize the probability distribution
        en_j = np.log(p_j.size(0)) + (p_j * torch.log(p_j)).sum()

        # Combine the entropy losses
        en_loss = en_i + en_j

        # Concatenate the augmented versions of c
        c = torch.cat((c_aug0.t(), c_aug1.t()), dim=0)
        n = c.shape[0]


        logprob = F.log_softmax(logits, dim=1)
        # choose all positive objects for an example, for i it would be (i + k * n/m), where k=0...(m-1)
        m = self.multiplier
        labels = (np.repeat(np.arange(n), m) + np.tile(np.arange(m) * n // m, n)) % n
        # remove labels pointet to itself, i.e. (i, i)
        labels = labels.reshape(n, m)[:, 1:].reshape(-1)

        loss = -logprob[np.repeat(np.arange(n), m - 1), labels].sum() / n / (m - 1)

        return loss + en_loss
    


class InstanceLoss(nn.Module):
    """
    Contrastive loss with distributed data parallel support
    """

    LARGE_NUMBER = 1e4

    def __init__(self, tau=0.5, multiplier=2):
        super().__init__()
        self.tau = tau
        self.multiplier = multiplier

    def forward(self, z, get_map=False):
        n = z.shape[0]
        assert n % self.multiplier == 0

        z = F.normalize(z, p=2, dim=1) / np.sqrt(self.tau) # 源代码中这个部分缺了l2 norm 有bug，这里
# 修改了

        logits = z @ z.t()
        logits[np.arange(n), np.arange(n)] = -self.LARGE_NUMBER ## 对角线部分mask

        logprob = F.log_softmax(logits, dim=1)

        # choose all positive objects for an example, for i it would be (i + k * n/m), where k=0...(m-1)
        m = self.multiplier
        labels = (np.repeat(np.arange(n), m) + np.tile(np.arange(m) * n // m, n)) % n
        # remove labels pointet to itself, i.e. (i, i)
        labels = labels.reshape(n, m)[:, 1:].reshape(-1)

        loss = -logprob[np.repeat(np.arange(n), m - 1), labels].sum() / n / (m - 1)

        return loss

class ClusterLossBoost(nn.Module):
    """
    Contrastive loss with distributed data parallel support
    """
    LARGE_NUMBER = 1e4

    def __init__(self, multiplier=1, distributed=False, cluster_num=7):
        super().__init__()
        self.multiplier = multiplier
        self.distributed = distributed
        self.cluster_num = cluster_num

    def forward(self, c, pseudo_label):
        pesudo_label_all = pseudo_label
        pseudo_index = pesudo_label_all != -1
        pesudo_label_all = pesudo_label_all[pseudo_index]
        idx, counts = torch.unique(pesudo_label_all, return_counts=True)
        freq = pesudo_label_all.shape[0] / counts.float()
        weight = torch.ones(self.cluster_num).to(c.device)
        weight[idx] = freq
        pseudo_index = pseudo_label != -1
        if pseudo_index.sum() > 0:
            criterion = nn.CrossEntropyLoss(weight=weight).to(c.device)
            loss_ce = criterion(
                c[pseudo_index], pseudo_label[pseudo_index].to(c.device)
            )
        else:
            loss_ce = torch.tensor(0.0, requires_grad=True).to(c.device)
        return loss_ce


class InstanceLossBoost(nn.Module):
    """
    Contrastive loss with distributed data parallel support
    """
    LARGE_NUMBER = 1e4

    def __init__(self, tau=0.5, multiplier=2, distributed=False, alpha=0.01, gamma=0.5, cluster_num=7):
        super().__init__()
        self.tau = tau
        self.multiplier = multiplier
        self.distributed = distributed
        self.alpha = alpha
        self.gamma = gamma
        self.cluster_num = cluster_num

    @torch.no_grad()
    def generate_pseudo_labels(self, c, pseudo_label_cur):
 
        batch_size = c.shape[0]
        device = c.device
        pseudo_label_nxt = -torch.ones(batch_size, dtype=torch.long).to(device)
        tmp = torch.arange(0, batch_size).to(device)

        prediction = c.argmax(dim=1)
        confidence = c.max(dim=1).values



        # 获取置信度从高到低排序的索引
        _, sorted_indices = torch.sort(confidence, descending=True)

        # 选择前1000个样本作为伪标签
        top_1000_indices = sorted_indices[:500]  # 取前1000个索引

        # 创建一个布尔张量，标记前1000个样本的索引
        unconfident_pred_index = torch.zeros_like(confidence, dtype=torch.bool)
        unconfident_pred_index[top_1000_indices] = True

        # unconfident_pred_index = confidence < self.alpha
        pseudo_per_class = np.ceil(batch_size / self.cluster_num * self.gamma).astype(
            int
        )
        for i in range(self.cluster_num):
            class_idx = prediction == i
            if class_idx.sum() == 0:
                continue
            confidence_class = confidence[class_idx]
            num = min(confidence_class.shape[0], pseudo_per_class)
            confident_idx = torch.argsort(-confidence_class)
            for j in range(num):
                idx = tmp[class_idx][confident_idx[j]]
                pseudo_label_nxt[idx] = i

        todo_index = pseudo_label_cur == -1
        pseudo_label_cur[todo_index] = pseudo_label_nxt[todo_index]
        pseudo_label_nxt = pseudo_label_cur
        pseudo_label_nxt[unconfident_pred_index] = -1

        unconfident_count = unconfident_pred_index.sum().item()

        # 输出 unconfident_pred_index 的数量
        # print(f"置信度低于 alpha 的样本数量: {unconfident_count}")
        unique_labels, counts = torch.unique(pseudo_label_nxt, return_counts=True)

        # 打印伪标签数量
        # print(f"伪标签的总数量: {pseudo_label_nxt.shape[0]}")
        # print("每个类别的伪标签数量：")

        # # 输出每个类别的伪标签数量
        # for label, count in zip(unique_labels, counts):
        #     print(f"类别 {label.item()}: {count.item()} 伪标签")


        return pseudo_label_nxt
    

    def forward(self, z, pseudo_label):
        n = z.shape[0]
        assert n % self.multiplier == 0

    # if self.distributed:
        z_list = [torch.zeros_like(z) for _ in range(1)]  # Only one device, so size is 1
        pseudo_label_list = [torch.zeros_like(pseudo_label) for _ in range(1)]  # Same as above
        # In a non-distributed setup, we don't need to gather across processes
        z_list[0] = z
        pseudo_label_list[0] = pseudo_label
        # Since we're no longer chunking across multiple processes, we only split based on the multiplier
        z_list = [chunk for x in z_list for chunk in x.chunk(self.multiplier)]
        pseudo_label_list = [chunk for x in pseudo_label_list for chunk in x.chunk(self.multiplier)]
        # In this simplified version, we don't need to sort across processes
        z_sorted = z_list
        pseudo_label_sorted = pseudo_label_list
        # Concatenate as before
        z_i = torch.cat(z_sorted[: int(self.multiplier / 2)], dim=0)
        z_j = torch.cat(z_sorted[int(self.multiplier / 2):], dim=0)
        pseudo_label = torch.cat(pseudo_label_sorted, dim=0)
        n = z_i.shape[0]

        invalid_index = pseudo_label == -1
        mask = torch.eq(pseudo_label.view(-1, 1), pseudo_label.view(1, -1)).to(
            z_i.device
        )
        mask[invalid_index, :] = False
        mask[:, invalid_index] = False
        mask_eye = torch.eye(n).float().to(z_i.device)
        mask &= ~(mask_eye.bool())
        mask = mask.float()

        contrast_count = self.multiplier
        contrast_feature = torch.cat((z_i, z_j), dim=0)

        anchor_feature = contrast_feature
        anchor_count = contrast_count

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T), self.tau
        )
        # for numerical stability
        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()

        # tile mask
        # mask_with_eye = mask | mask_eye.bool()
        # mask = torch.cat(mask)
        mask = mask.repeat(anchor_count, contrast_count)
        mask_eye = mask_eye.repeat(anchor_count, contrast_count)
        # mask-out self-contrast cases
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(n * anchor_count).view(-1, 1).to(z_i.device),
            0,
        )
        logits_mask *= 1 - mask
        mask_eye = mask_eye * logits_mask

        # compute log_prob
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (mask_eye * log_prob).sum(1) / mask_eye.sum(1)

        # loss
        instance_loss = -mean_log_prob_pos
        instance_loss = instance_loss.view(anchor_count, n).mean()

        return instance_loss