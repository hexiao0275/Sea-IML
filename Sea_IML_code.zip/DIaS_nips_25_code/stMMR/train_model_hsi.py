# -*- coding: utf-8 -*-
from sklearn import metrics
from sklearn.cluster import KMeans
from stMMR.process import *
from stMMR import models_hsi

import datetime
import torch.optim as optim
from stMMR.utils import *

from sklearn.metrics import confusion_matrix
from scipy.optimize import linear_sum_assignment

import xgboost
import shap
import matplotlib.pyplot as plt

from stMMR.spaVAE.SVGP_yuan import SVGP
from torch.distributions import Normal
from torch.distributions import kl_divergence as kl
from torch.distributions import kl_divergence
from sklearn.preprocessing import MinMaxScaler

import warnings
warnings.filterwarnings('ignore')
from sklearn.decomposition import PCA
import sklearn

from torch.autograd import Variable
import torch

def mi_loss(
    q_i: torch.Tensor,
    q_t: torch.Tensor,
):
    """
    Compute MI loss terms for SIMVI using q_i and q_t.
    """
    # Use q_t as the "y" representation and q_i as the "x" representation
    psi_x = q_i
    psi_y = q_t.detach()

    C_yy = s_cov(psi_y, psi_y)
    C_yx = s_cov(psi_y, psi_x)
    C_xy = s_cov(psi_x, psi_y)
    C_xx = s_cov(psi_x, psi_x)

    C_xx_inv = torch.inverse(C_xx + torch.eye(C_xx.shape[0], device=psi_x.device) * 1e-3)

    l2 = -torch.logdet(C_yy - torch.linalg.multi_dot([C_yx, C_xx_inv, C_xy])) + torch.logdet(C_yy)
    return l2

def s_cov( psi_x, psi_y):
    """
    :return: covariance matrix
    """
    N = psi_x.shape[0]
    return (psi_y.T @ psi_x).T / (N - 1)

def mmd_loss(
    q_i: torch.Tensor,
    q_t: torch.Tensor,
):
    """
    Compute MMD loss terms for SIMVI using q_i and q_t.
    """
    z = q_i
    s = q_t.detach()
    sample = torch.cat((z, s), 1)
    true_samples = torch.randn(sample.shape[0], sample.shape[1], device=z.device)
    l1 = compute_mmd(sample, true_samples)

    return l1

def compute_mmd( x, y):
    x_kernel = compute_kernel(x, x)
    y_kernel = compute_kernel(y, y)
    xy_kernel = compute_kernel(x, y)
    mmd = x_kernel.mean() + y_kernel.mean() - 2 * xy_kernel.mean()
    return mmd

def compute_kernel(x, y):
    x_size = x.size(0)
    y_size = y.size(0)
    dim = x.size(1)
    x = x.unsqueeze(1)  # (x_size, 1, dim)
    y = y.unsqueeze(0)  # (1, y_size, dim)
    tiled_x = x.expand(x_size, y_size, dim)
    tiled_y = y.expand(x_size, y_size, dim)
    kernel_input = (tiled_x - tiled_y).pow(2).mean(2) / float(dim)
    return torch.exp(-kernel_input)  # (x_size, y_size)


def train(adata,fadj,sadj,knn=7,fft_ratio = 1.0,h=[3000,3000], n_epochs=200,lr=0.0001, key_added='stMMR', random_seed=100,res=1,
          l=2,weight_decay=0.0001,a=10,b=1,c=10,embed=True,radius=0,enhancement=False,cluster="kmeans",loss_type="consistency",
                device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')):
    set_seed(random_seed)
    if 'highly_variable' in adata.var.columns:
        adata_Vars =  adata[:, adata.var['highly_variable']]
        adata_Vars_text =  adata.text[:, adata.text.var['highly_variable']]
    else:
        adata_Vars = adata
        adata_Vars_text = adata.text

    obs_df = adata_Vars.obs.dropna()


    labels =  obs_df['ground_truth'].astype(int) - 1
    if type(adata.X) == np.ndarray:
        features_X = torch.FloatTensor(adata_Vars.X).to(device)

    else:
        features_X = torch.FloatTensor(adata_Vars.X.toarray()).to(device)

    if type(adata.text.X) == np.ndarray:
        features_Text = torch.FloatTensor(adata_Vars_text.X).to(device)
    else:
        features_Text= torch.FloatTensor(adata_Vars_text.X.toarray()).to(device)

    # features_I = torch.FloatTensor(adata_Vars.obsm["im_re"].values).to(device)
    features_I = torch.FloatTensor(adata_Vars.X).to(device)


    fadj.to(device)
    sadj.to(device)


    loc_range = 20.
    # Move fadj to CPU and convert to NumPy array
    fadj_np = fadj.cpu().numpy()
    # Initialize the scaler
    scaler = MinMaxScaler()
    # Fit and transform the data
    scaled_data = scaler.fit_transform(fadj_np) * loc_range
    # Convert to PyTorch tensor and move back to GPU
    loc = torch.tensor(scaled_data).to('cuda')

    model =models_hsi.stMMR(nfeatX=features_X.shape[1],
                 nfeatI=features_I.shape[1],
                    nfeatT=features_Text.shape[1],
                    hidden_dims=h,
                    fft_ratio = fft_ratio,
                    feature_num = features_X.shape[0],
                    sadj=sadj,
                    fadj=  fadj
                    ).to(device)
        

    features_all = torch.cat((features_X, features_I,features_Text), dim=1)

    # for param in model.GCN_A.parameters():
    #     param.requires_grad = True

    # trainable_params = filter(lambda p: p.requires_grad, c)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    # optimizer = optim.SGD(model.parameters(), lr=lr, weight_decay=weight_decay)
    mean_max = []
    #模型训练
    ari_max = 0
    ari_res = 0
    nmi_res = 0
    nmi_max = 0

    pseudo_labels = -torch.ones(features_all.shape[0], dtype=torch.long).to(device)
    
    for epoch in range(n_epochs):
        # edge_dropout_rate = 0.2
        # num_edge_additions = 50
        # aug_adj = adj.clone()
        # aug_adj = augment_graph(aug_adj, edge_dropout_rate, num_edge_additions)
        if 50 <= epoch % 30 <= 50:
 
            criterion_clu = ClusterLossBoost(distributed=True, cluster_num=7)
            criterion_ins = InstanceLossBoost(
                tau=0.5, distributed=True, alpha=0.2, gamma=0.5,cluster_num=7
            )
            optimizer.zero_grad()
            model.eval()
            z_xi, q_x, q_i, q_t, pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j ,z_xti,c_xti,z_k,c_k , emb_x_qnet_mu, emb_x_qnet_var, elbo_z_t= model(features_all,loc)
            c_xti = F.softmax(c_xti / 1.0, dim=1)
    # Update pseudo labels without index
            pseudo_labels_cur = criterion_ins.generate_pseudo_labels(c_xti, pseudo_labels)
            pseudo_index = pseudo_labels_cur != -1

            model.train(True)

            z_xi, q_x, q_i, q_t, pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j ,z_xti,c_xti,z_k,c_k, emb_x_qnet_mu, emb_x_qnet_var,elbo_z_t = model(features_all,loc)
            loss_ins = criterion_ins(torch.concat((z_xti, z_i), dim=0), pseudo_labels_cur)
            loss_ins_2 = criterion_ins(torch.concat((z_xti, z_j), dim=0), pseudo_labels_cur)
            loss_ins_3 = criterion_ins(torch.concat((z_xti, z_k), dim=0), pseudo_labels_cur)

            loss_clu = criterion_clu(c_xti, pseudo_labels_cur)

            loss_tcl = (loss_ins + loss_clu + loss_ins_2 +loss_ins_3) * 0.5

        else:
                        
    ##################################################################################################################
            model.train()
            optimizer.zero_grad()


            z_xi, q_x, q_i, q_t, pi, disp, mean ,  emb_x,emb_i, emb_t, z_i,z_j,c_i,c_j ,z_xti,c_xti,z_k,c_k, emb_x_qnet_mu, emb_x_qnet_var, elbo_z_t = model(features_all,loc)

            # c_i = F.softmax(c_i, dim=1)
            # c_j = F.softmax(c_j, dim=1) 
            # c_k = F.softmax(c_k, dim=1) 
            # c_xti = F.softmax(c_xti, dim=1) 

        

            # loss_ins = InstanceLoss()(torch.concat((z_xti, z_i), dim=0))
            # loss_clu = ClusterLoss()(torch.concat((c_xti, c_i), dim=0))

            # loss_ins_2 = InstanceLoss()(torch.concat((z_xti, z_j), dim=0))
            # loss_clu_2 = ClusterLoss()(torch.concat((c_xti, c_j), dim=0))


            # loss_ins_3 = InstanceLoss()(torch.concat((z_xti, z_k), dim=0))
            # loss_clu_3 = ClusterLoss()(torch.concat((c_xti, c_k), dim=0))

            # loss_tcl = (loss_ins + loss_clu + loss_ins_2  + loss_clu_2+ loss_ins_3 + loss_clu_3) * 0.5

        zinb_loss = ZINB(pi, theta=disp, ridge_lambda=1).loss(features_X, mean, mean=True)


    #     if loss_type == "consistency":
    # # 使用MMD损失替代一致性损失，目的是拉远 q_t 和 q_i/q_x 的分布
    #         cl_loss = mmd_loss(q_i, q_t)  # 拉远 q_t 和 q_i
    #         # cl_loss = mi_loss(q_i, q_t)  # 拉远 q_t 和 q_i
    #         # cl_loss_2 = mmd_loss(q_i, q_x)  # 拉远 q_t 和 q_x
    #         # cl_loss_2 = mmd_loss(q_t, q_x)  # 拉远 q_t 和 q_x
    #         # cl_loss = (cl_loss_1 + cl_loss_2) / 2.0  # 平均MMD损失
    #     else:
    #         cl_loss = crossview_contrastive_Loss(q_x, q_i)

        # noise_node_loss =  SimilarityLoss(z_xi, graph_nei)

        # reg_loss_nei = regularization_loss_graph_nei(z_xi, graph_nei_sp, graph_neg_sp)
        # reg_loss = regularization_loss(z_xi, sadj)

        a=10
        b=10
        c=10


        total_loss = a * zinb_loss 
        
        
        total_loss.backward()
        optimizer.step() 

        if 'ground_truth' in adata.obs.columns:
            if cluster == "kmeans":
                # kmeans = KMeans(n_clusters=knn,random_state=random_seed).fit(np.nan_to_num(z_xi.cpu().detach()))

                # z_xi_combined = torch.cat((z_xi, z_xi), dim=1)
                kmeans = KMeans(n_clusters=knn).fit(z_xi.cpu().detach())
                idx = kmeans.labels_
                adata_Vars.obs['temp']=idx
                obs_df = adata_Vars.obs.dropna()
                ari_res = metrics.adjusted_rand_score(obs_df['temp'], obs_df['ground_truth'])
                nmi_res = metrics.normalized_mutual_info_score(obs_df['temp'], obs_df['ground_truth'])
            else:
                adata_Vars.obsm["letemp"]=z_xi.to('cpu').detach().numpy()
                sc.pp.neighbors(adata_Vars, use_rep='letemp')
                sc.tl.leiden(adata_Vars, key_added="temp", resolution=res)
                obs_df = adata_Vars.obs.dropna()
                ari_res = metrics.adjusted_rand_score(obs_df['temp'], obs_df['ground_truth'])
                nmi_res = metrics.normalized_mutual_info_score(obs_df['temp'], obs_df['ground_truth'])
                idx=adata_Vars.obs['temp'].values
                count_unique_leiden = len(pd.DataFrame(adata_Vars.obs['temp']).temp.unique())
                print("num of cluster:",count_unique_leiden)
            if ari_res > ari_max:
                ari_max = ari_res
                idx_max = idx
                mean_max = mean.to('cpu').detach().numpy()
                emb_max = z_xi.to('cpu').detach().numpy()

                # torch.save(emb_x, 'datashow_pt/emb_x.pt')
                # torch.save(emb_i, 'datashow_pt/emb_i.pt')
                # torch.save(emb_t, 'datashow_pt/emb_t.pt')

        if epoch % 1 == 0:
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[{current_time}] Epoch: {epoch}/{n_epochs}, Loss: {total_loss:.4f},  ARI: {ari_res:.4f},  NMI: {nmi_res:.4f}")
            adata.obs['idx'] = idx_max.astype(str)


            # Create the SHAP explainer
            # explainer = shap.DeepExplainer(model, features_all)

            # # Get SHAP values
                        
            # T_1 = torch.tensor(features_all).to(device)
            # shap_values = explainer.shap_values(T_1[:2].to_dense())

    savepath = 'mgcn_denoise_result/'
    pd.DataFrame(emb_max).to_csv(savepath + 'Spatial_MGCN_emb.csv')
    pd.DataFrame(idx_max).to_csv(savepath + 'Spatial_MGCN_idx.csv')
    adata.layers['X'] = adata.X
    adata.layers['mean'] = mean_max
    adata.write(savepath + 'Spatial_MGCN.h5ad')
    


    labels.replace('1', 't0', inplace=True)
    labels.replace('2', 't1', inplace=True)
    labels.replace('3', 't2', inplace=True)
    labels.replace('4', 't3', inplace=True)
    labels.replace('5', 't4', inplace=True)
    labels.replace('6', 't5', inplace=True)
    labels.replace('0', 't6', inplace=True)

    labels.replace('t0', '0', inplace=True)
    labels.replace('t1', '1', inplace=True)
    labels.replace('t2', '2', inplace=True)
    labels.replace('t3', '3', inplace=True)
    labels.replace('t4', '4', inplace=True)
    labels.replace('t5', '5', inplace=True)
    labels.replace('t6', '6', inplace=True)

    labels_int = [int(x) for x in labels]
    true = labels_int
    pred_1 = idx_max
    cm = confusion_matrix(true, pred_1)
    # 使用匈牙利算法进行标签重映射
    row_ind, col_ind = linear_sum_assignment(-cm)
    # 创建映射字典
    label_mapping = {col_ind[i]: row_ind[i] for i in range(len(row_ind))}
    # 根据映射重映射预测标签
    idx_max = np.array([label_mapping[label] for label in pred_1])

    adata.obs['idx'] = idx_max.astype(str)
    
    if 'ground_truth' in adata.obs.columns:
        print("Ari=", ari_max)
    else:
        if cluster == "kmeans":
            kmeans = KMeans(n_clusters=knn).fit(z_xi.cpu().detach())
            idx_max = kmeans.labels_
            emb_max = z_xi.to('cpu').detach().numpy()
            # mean_max = mean.to('cpu').detach().numpy()
        else:
            adata_Vars.obsm["letemp"] = z_xi.to('cpu').detach().numpy()
            sc.pp.neighbors(adata_Vars, use_rep='letemp')
            sc.tl.leiden(adata_Vars, key_added="temp", resolution=res)
            idx_max = adata_Vars.obs['temp'].values
            count_unique_leiden = len(pd.DataFrame(adata_Vars.obs['temp']).temp.unique())
            emb_max = z_xi.to('cpu').detach().numpy()
            mean_max = mean.to('cpu').detach().numpy()
            print("num of cluster:", count_unique_leiden)
    if embed:
        pca = PCA(n_components=5, random_state=random_seed)
        adata.obsm['emb_pca'] = pca.fit_transform(emb_max.copy())


    labels.replace('1', 't0', inplace=True)
    labels.replace('2', 't1', inplace=True)
    labels.replace('3', 't2', inplace=True)
    labels.replace('4', 't3', inplace=True)
    labels.replace('5', 't4', inplace=True)
    labels.replace('6', 't5', inplace=True)
    labels.replace('0', 't6', inplace=True)

    labels.replace('t0', '0', inplace=True)
    labels.replace('t1', '1', inplace=True)
    labels.replace('t2', '2', inplace=True)
    labels.replace('t3', '3', inplace=True)
    labels.replace('t4', '4', inplace=True)
    labels.replace('t5', '5', inplace=True)
    labels.replace('t6', '6', inplace=True)

    labels_int = [int(x) for x in labels]
    true = labels_int
    pred_1 = idx_max
    cm = confusion_matrix(true, pred_1)
    # 使用匈牙利算法进行标签重映射
    row_ind, col_ind = linear_sum_assignment(-cm)
    # 创建映射字典
    label_mapping = {col_ind[i]: row_ind[i] for i in range(len(row_ind))}
    # 根据映射重映射预测标签
    idx_max = np.array([label_mapping[label] for label in pred_1])


    adata.obs['idx'] = idx_max.astype(str)
    adata.obsm['emb'] = emb_max
    adata.obsm['mean'] = mean_max


    adata.obs["cluster"] = idx_max.astype(str)
    if radius !=0 :
        nearest_new_type = refine_label(adata, radius=radius)
        adata.obs[key_added] = nearest_new_type
    else:
        adata.obs[key_added] = adata.obs["cluster"]
    adata.obsm["emb"] = emb_max
    adata.obsm['mean'] = mean_max

    if enhancement:
        mean_max = sklearn.preprocessing.normalize(mean_max, axis=1, norm='max')
        adata.layers[key_added] = mean_max

    # sc.pp.neighbors(adata, use_rep='emb_pca')
    # sc.tl.umap(adata)
    # plt.rcParams["figure.figsize"] = (3, 3)
    # sc.pl.umap(adata, color=[key_added, "ground_truth"], title=['stMMR (ARI=%.2f)' % ari_max, "Ground Truth"],
    #            save="tt.pdf")
    return adata




