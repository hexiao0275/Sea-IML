# -*- coding: utf-8 -*-
from sklearn import metrics
from sklearn.cluster import KMeans
from stMMR.process import *
from stMMR import models_copy as models
import datetime
import torch.optim as optim
from stMMR.utils import *

from sklearn.metrics import confusion_matrix
from scipy.optimize import linear_sum_assignment
import matplotlib.pyplot as plt


import warnings
warnings.filterwarnings('ignore')
from sklearn.decomposition import PCA
import sklearn
def train(adata,fadj,sadj,knn=10,h=[512,16], n_epochs=200,lr=0.0001, key_added='stMMR', random_seed=100,res=1,
          l=2,weight_decay=0.0001,a=10,b=1,c=10,embed=True,radius=0,enhancement=False,cluster="kmeans",loss_type="consistency",
                device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')):
    set_seed(random_seed)
    if 'highly_variable' in adata.var.columns:
        adata_Vars =  adata[:, adata.var['highly_variable']]
        adata_Vars_text =  adata.text[:, adata.text.var['highly_variable']]
    else:
        adata_Vars = adata
        adata_Vars_text = adata.text
    # labels = adata_Vars.obs['ground_truth']
    if type(adata.X) == np.ndarray:
        features_X = torch.FloatTensor(adata_Vars.X).to(device)
    else:
        features_X = torch.FloatTensor(adata_Vars.X.toarray()).to(device)


    if type(adata.text.X) == np.ndarray:
        features_Text = torch.FloatTensor(adata_Vars_text.X).to(device)
    else:
        features_Text= torch.FloatTensor(adata_Vars_text.X.toarray()).to(device)

    # if type(adata.text.X) == np.ndarray:
    #     features_Text = torch.FloatTensor(adata_Vars_text.X).to(device)
    # else:
    #     features_Text= torch.FloatTensor(adata_Vars_text.X.toarray()).to(device)

    # features_I = torch.FloatTensor(adata_Vars.obsm["im_re"].values).to(device)
    features_I = torch.FloatTensor(adata_Vars.X).to(device)

    fadj.to(device)
    sadj.to(device)
    # adj=adata_Vars.obsm["adj"]
    # adj = np.exp(-1*(adj**2)/(2*(l**2)))
    # adj = sp.coo_matrix(adj)
    # adj = normalize(adj + sp.eye(adj.shape[0]))
    # adj = sparse_mx_to_torch_sparse_tensor(adj).to(device)

    # fadj = adata.obsm['fadj']
    # sadj = adata.obsm['sadj']

    # sadj_sp = adata.obsm['sadj_sp']
    # nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    # nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    # nsadj = normalize_sparse_matrix(sadj_sp + sp.eye(sadj_sp.shape[0]))
    # sadj = sparse_mx_to_torch_sparse_tensor(nsadj)

    # sadj = sadj.to(device)

    model =models.stMMR(nfeatX=features_X.shape[1],
                 nfeatI=features_I.shape[1],
                    nfeatT=features_Text.shape[1],
                    hidden_dims=h,
                    ).to(device)
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)
    # optimizer = optim.SGD(model.parameters(), lr=lr, weight_decay=weight_decay)
    mean_max = []
    #模型训练
    ari_max = 0
    ari_res = 0
    nmi_res = 0
    nmi_max = 0
    
   
    graph_nei = adata.obsm["graph_nei"]
    graph_nei =  torch.from_numpy(graph_nei).to(device)
    graph_neg = adata.obsm["graph_neg"]
    graph_neg =  torch.from_numpy(graph_neg).to(device)


    graph_nei_sp = adata.obsm["graph_nei_sp"]
    graph_nei_sp =  torch.from_numpy(graph_nei_sp).to(device)
    graph_neg_sp = adata.obsm["graph_neg_sp"]
    graph_neg_sp =  torch.from_numpy(graph_neg_sp).to(device)


    for epoch in range(n_epochs):
        # edge_dropout_rate = 0.2
        # num_edge_additions = 50
        # aug_adj = adj.clone()
        # aug_adj = augment_graph(aug_adj, edge_dropout_rate, num_edge_additions)


        model.train()
        optimizer.zero_grad()


        z_xi, q_x, q_i, q_t, pi, disp, mean ,  emb_x,emb_i, emb_t= model(features_X, features_I, features_Text, fadj,sadj)

        zinb_loss = ZINB(pi, theta=disp, ridge_lambda=1).loss(features_X, mean, mean=True)

        if loss_type == "consistency":
            cl_loss_1 = consistency_loss(q_x, q_t)
            cl_loss_2 = consistency_loss(q_x, q_i)
            cl_loss = (cl_loss_1 + cl_loss_2  )/2.0
        else:
            cl_loss = crossview_contrastive_Loss(q_x, q_i)

        noise_node_loss =  SimilarityLoss(z_xi, graph_nei)

        reg_loss_nei = regularization_loss_graph_nei(z_xi, graph_nei_sp, graph_neg_sp)
        reg_loss = regularization_loss(z_xi, fadj)

        # a=1
        # b=10
        # c=0.1

        # a = 10
        # b = 1
        # c = 0.1


        # total_loss = a * zinb_loss  + b * cl_loss + c * reg_loss * 0.001 + c * reg_loss_nei * 0.9+  noise_node_loss* 0.0001



        # HBC
        # a=10
        # b=1
        # c=10

        a=10
        b=10
        c=10
        
        total_loss = a * zinb_loss  + b * cl_loss + c * reg_loss * 0.001 + c * reg_loss_nei * 0.9+  noise_node_loss* 0.0001


        total_loss.backward()
        optimizer.step() 
        # if epoch % 1 == 0:
        #     current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        #     print(f"[{current_time}] Epoch: {epoch}/{n_epochs}, Loss: {total_loss:.4f},  ARI: {ari_res:.4f},  NMI: {nmi_res:.4f}")

        if 'ground_truth' in adata.obs.columns:
            if cluster == "kmeans":
                # kmeans = KMeans(n_clusters=knn,random_state=random_seed).fit(np.nan_to_num(z_xi.cpu().detach()))


                kmeans = KMeans(n_clusters=knn).fit(z_xi.cpu().detach())
                idx = kmeans.labels_
                adata_Vars.obs['temp']=idx
                obs_df = adata_Vars.obs.dropna()
                ari_res = metrics.adjusted_rand_score(obs_df['temp'], obs_df['ground_truth'])
                nmi_res = metrics.normalized_mutual_info_score(obs_df['temp'], obs_df['ground_truth'])
            else:
                adata_Vars.obsm["letemp"]=z_xi.to('cpu').detach().numpy()
                sc.pp.neighbors(adata_Vars, use_rep='letemp')
                sc.tl.leiden(adata_Vars, key_added="temp", resolution=res)
                obs_df = adata_Vars.obs.dropna()
                ari_res = metrics.adjusted_rand_score(obs_df['temp'], obs_df['ground_truth'])
                nmi_res = metrics.normalized_mutual_info_score(obs_df['temp'], obs_df['ground_truth'])
                idx=adata_Vars.obs['temp'].values
                count_unique_leiden = len(pd.DataFrame(adata_Vars.obs['temp']).temp.unique())
                print("num of cluster:",count_unique_leiden)
            if ari_res > ari_max:
                ari_max = ari_res
                idx_max = idx
                mean_max = mean.to('cpu').detach().numpy()
                emb_max = z_xi.to('cpu').detach().numpy()

                # torch.save(emb_x, 'datashow_pt/emb_x.pt')
                # torch.save(emb_i, 'datashow_pt/emb_i.pt')
                # torch.save(emb_t, 'datashow_pt/emb_t.pt')

        if epoch % 1 == 0:
            current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"[{current_time}] Epoch: {epoch}/{n_epochs}, Loss: {total_loss:.4f},  ARI: {ari_res:.4f},  NMI: {nmi_res:.4f}")
            adata.obs['idx'] = idx_max.astype(str)


    # savepath = 'mgcn_denoise_result/'
    # pd.DataFrame(emb_max).to_csv(savepath + 'Spatial_MGCN_emb.csv')
    # pd.DataFrame(idx_max).to_csv(savepath + 'Spatial_MGCN_idx.csv')
    # adata.layers['X'] = adata.X
    # adata.layers['mean'] = mean_max
    # adata.write(savepath + 'Spatial_MGCN.h5ad')
    
    # labels.replace('1', 't0', inplace=True)
    # labels.replace('2', 't1', inplace=True)
    # labels.replace('3', 't2', inplace=True)
    # labels.replace('4', 't3', inplace=True)
    # labels.replace('5', 't4', inplace=True)
    # labels.replace('6', 't5', inplace=True)
    # labels.replace('0', 't6', inplace=True)

    # labels.replace('t0', '0', inplace=True)
    # labels.replace('t1', '1', inplace=True)
    # labels.replace('t2', '2', inplace=True)
    # labels.replace('t3', '3', inplace=True)
    # labels.replace('t4', '4', inplace=True)
    # labels.replace('t5', '5', inplace=True)
    # labels.replace('t6', '6', inplace=True)

    # labels_int = [int(x) for x in labels]
    # true = labels_int
    # pred_1 = idx_max
    # cm = confusion_matrix(true, pred_1)
    # # 使用匈牙利算法进行标签重映射
    # row_ind, col_ind = linear_sum_assignment(-cm)
    # # 创建映射字典
    # label_mapping = {col_ind[i]: row_ind[i] for i in range(len(row_ind))}
    # # 根据映射重映射预测标签
    # idx_max = np.array([label_mapping[label] for label in pred_1])


    adata.obs['idx'] = idx_max.astype(str)
    adata.obsm['emb'] = emb_max
    adata.obsm['mean'] = mean_max



    if 'ground_truth' in adata.obs.columns:
        print("Ari=", ari_max)
    else:
        if cluster == "kmeans":
            kmeans = KMeans(n_clusters=knn).fit(z_xi.cpu().detach())
            idx_max = kmeans.labels_
            emb_max = z_xi.to('cpu').detach().numpy()
            mean_max = mean.to('cpu').detach().numpy()
        else:
            adata_Vars.obsm["letemp"] = z_xi.to('cpu').detach().numpy()
            sc.pp.neighbors(adata_Vars, use_rep='letemp')
            sc.tl.leiden(adata_Vars, key_added="temp", resolution=res)
            idx_max = adata_Vars.obs['temp'].values
            count_unique_leiden = len(pd.DataFrame(adata_Vars.obs['temp']).temp.unique())
            emb_max = z_xi.to('cpu').detach().numpy()
            mean_max = mean.to('cpu').detach().numpy()
            print("num of cluster:", count_unique_leiden)
    if embed:
        pca = PCA(n_components=20, random_state=random_seed)
        adata.obsm['emb_pca'] = pca.fit_transform(emb_max.copy())

    adata.obs["cluster"] = idx_max.astype(str)
    if radius !=0 :
        nearest_new_type = refine_label(adata, radius=radius)
        adata.obs[key_added] = nearest_new_type
    else:
        adata.obs[key_added] = adata.obs["cluster"]
    adata.obsm["emb"] = emb_max
    adata.obsm['mean'] = mean_max
    if enhancement:
        mean_max = sklearn.preprocessing.normalize(mean_max, axis=1, norm='max')
        adata.layers[key_added] = mean_max
    sc.pp.neighbors(adata, use_rep='emb_pca')
    sc.tl.umap(adata)
    plt.rcParams["figure.figsize"] = (3, 3)
    sc.pl.umap(adata, color=[key_added, "ground_truth"], title=['stMMR (ARI=%.2f)' % ari_max, "Ground Truth"],
               save="tt.pdf")
    return adata
