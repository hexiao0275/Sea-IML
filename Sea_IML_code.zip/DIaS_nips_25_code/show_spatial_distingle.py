
import logging
import warnings
from functools import partial
from typing import Dict, Iterable, List, Optional, Sequence, Union


import numpy as np
import pandas as pd
import math
import torch
import scanpy as sc
from sklearn.neighbors import kneighbors_graph
# from torch_geometric.utils import from_scipy_sparse_matrix
from scipy.spatial import Delaunay
# import pytorch_lightning as pl
import torch.optim as optim

from tqdm import tqdm
import torch.nn.functional as F
from torch.nn.utils import clip_grad_value_
from scipy.sparse import coo_matrix, csr_matrix
from sklearn.linear_model import LinearRegression, RidgeCV
from sklearn.metrics import r2_score
from sklearn.ensemble import RandomForestRegressor
from scipy.sparse import issparse
from scipy.stats import f
from statsmodels.stats.multitest import fdrcorrection

from anndata import AnnData



def get_archetypes(
    embedding,
    noc=5,
    delta=0.1,
    conv_crit=0.00001,
    maxiter=200,
    verbose=False,
) -> np.ndarray:
    """
    Calculate archetypal analysis for the input latent representation. A preliminary step for `get_se` function.

    Parameters
    ----------
    embedding : np.ndarray
            Input data matrix where each row represents a cell.
    noc : int, default: 5
            Number of archetypes to extract.
    delta : float, default: 0.1
            The relaxation parameter in PCHA algorithm.
    conv_crit : float, default: 0.00001
            Convergence criterion. Algorithm stops when the relative change in objective function is less than this.
    maxiter : int, default: 200
            Maximum number of iterations.
    verbose : bool, default: False
            Whether to print progress during optimization.

    Returns
    -------
    Tuple
            Returns a tuple containing:
            - Feature loading matrix (shape: (n_archetypes, latent_dim))
            - Archetypal representation matrix (shape: (n_cells, n_archetypes))
            - Explained variance ratio
    """

    from py_pcha import PCHA
    XC, S, C, SSE, varexpl = PCHA(embedding.T, noc=noc, delta=delta,conv_crit=conv_crit, maxiter=maxiter, verbose=verbose)
    
    return XC.T, S, varexpl  

def return_f_pv(X,Rsq):
    """
    Helper function for calculating p values of spatial effects.
    """
    N = X.shape[0]
    K = X.shape[1] + 1
    fstat = (Rsq/(1-Rsq))*((N-K-1)/K)

    df_model = X.shape[1]
    df_residuals = X.shape[0] - X.shape[1] + 1
    p_values = f.sf(fstat, df_model, df_residuals)
    
    rej, adj_p = fdrcorrection(p_values)
    return adj_p

def get_se(
    edge_index: Optional[torch.Tensor] = None,
    adata: Optional[AnnData] = None,
    z_label: Optional[str] = 'simvi_z',
    s_label: Optional[str] = 'simvi_s',
    transformation = 'log1p',
    batch_label = None,
    num_arch = 5,
    delta = 0.1,
    maxiter = 200,
    Kfold = 5,
    eps = 0,
    thres = 0.95,
    positivity_filter = False,
    cell_type_label = None,
    obsm_label = None,
    mode = 'individual',
) -> np.ndarray:
    """
    Return the spatial effect for each cell in spatial omics data. Requires training the SIMVI model in priori.  

    Parameters
    ----------
    edge_index : torch.Tensor
            The object created by function "extract_edge_index".
    adata : AnnData, optional
            AnnData object with equivalent structure to initial AnnData. If `None`,
            defaults to the AnnData object used to initialize the model.
    z_label : str, optional
            The name of the intrinsic variation in adata.obsm. If adata is `None`, 
            then it is calculated in this function.
    s_label : str, optional
            The name of the spatial variation in adata.obsm. If adata is `None`, 
            then it is calculated in this function.
    transformation : str, default: 'log1p'
            If `log1p`, perform log1p on a copy of the data. Else, operate on the given adata.X.
    batch_label : str, optional
            If given, then add it as a covariate in the double machine learning model.
    num_arch : int, default: 5
            Number of archetypes in archetypal transformation.
    delta : float, default: 0.1
            Delta parameter in archetypal transformation.
    maxiter : int, default: 200
            Maximum iterations in archetypal transformation.
    Kfold : int, default: 5
            Number of folds in cross validation.
    eps : float, default: 0
            Epsilon parameter in archetypal transformation.
    thres : float, default: 0.95
            Thres2 in positivity index calculation.
    positivity_filter : bool, default: False
            If True, only return the spatial effect of cells satisfying positivity condition,
            and return the indices of these cells.
    cell_type_label : str, optional
            If given, then add it as a covariate in the double machine learning model.
    obsm_label : str, optional
            If given, then add it as a covariate in the double machine learning model. 

    Returns
    -------
    Union[tuple, tuple]
            If positivity is `False`, return (spatial_effect, R2s, p_values, archetypes).
            If positivity is `True`, return (positive_indices, spatial_effect, R2s, p_values, archetypes). 
    """
    adata_tmp = adata.copy()
    
    latent_z = adata_tmp.obsm[z_label]
    latent_s = adata_tmp.obsm[s_label]
        
    ## estimate generalized propensity score
    if transformation == 'log1p':
        sc.pp.normalize_total(adata_tmp)
        sc.pp.log1p(adata_tmp)
        
    if batch_label is not None:
        df = pd.get_dummies(adata_tmp.obs[batch_label]).values
        latent_z = np.hstack((latent_z,df))
        
    if cell_type_label is not None:
        df2 = pd.get_dummies(adata_tmp.obs[cell_type_label]).values
        latent_z = np.hstack((latent_z,df2))
        #df2_ = df2 / df2.sum(axis=0) 
        
    if obsm_label is not None:
        df3 = np.asarray(adata_tmp.obsm[obsm_label])
        latent_z = np.hstack((latent_z,df3))

    if issparse(adata_tmp.X):
        adata_tmp.X = adata_tmp.X.toarray()
        
    arc, S, varexpl = get_archetypes(latent_s,noc=num_arch,delta=delta,maxiter=maxiter)
    
    ## S is the continuous treatment variable
    S = np.asarray(S.T)
    
    if positivity_filter:
        sc.pp.neighbors(adata_tmp,use_rep=z_label)
        sc.tl.leiden(adata_tmp,resolution=0.6)
        df = pd.DataFrame(S.copy())
        df = (df>0.5).astype(int)
        df['cluster'] = adata_tmp.obs['leiden'].values.copy()
        df = df.loc[df.sum(axis=1)>0]
        df_ = pd.DataFrame(df.groupby('cluster').mean().max(axis=0))
        
        positive_indices = ((pd.DataFrame(S.copy(),index=adata_tmp.obs_names).loc[:,df_.values>=thres]>0.5).sum(axis=1) == 0)
        adata_tmp = adata_tmp[positive_indices]
        latent_z = latent_z[positive_indices]
        latent_s = latent_s[positive_indices]
        S = S[positive_indices]
        S = S[:,df_.values.flatten()<thres]
    
    np.random.seed(42)
    indices = np.random.permutation(latent_z.shape[0])
    split_data = np.array_split(indices, Kfold)        
    
    
    
    if mode == 'individual':     
        se_list = []
        r2_zlist = []
        r2_slist = []
        r2_zpvlist = []
        r2_spvlist = []
        for i in range(S.shape[1]):
            se = np.zeros((latent_z.shape[0],adata_tmp.shape[1]))
            r2_z = np.zeros(adata_tmp.shape[1])
            r2_s = np.zeros(adata_tmp.shape[1])
            for ind in split_data:
                Si = S[ind,i]
                lr = LinearRegression()
                lr.fit(latent_z[ind],Si)
                lr2 = LinearRegression()
                lr2.fit(latent_z[ind],adata_tmp.X[ind])
                Si_ = Si - lr.predict(latent_z[ind])
                X_ = adata_tmp.X[ind] - lr2.predict(latent_z[ind])
                lr3 = LinearRegression()
                lr3.fit(latent_z[ind],X_ / (Si_[:,None]+eps),sample_weight = Si_ ** 2)
                se[ind] = lr3.predict(latent_z[ind]) * Si_[:,None]
                r2_z = r2_z + r2_score(adata_tmp.X[ind],lr2.predict(latent_z[ind]), multioutput='raw_values')
                r2_s = r2_s + r2_score(X_, lr3.predict(latent_z[ind]) * Si_[:,None], multioutput='raw_values')
            
        #if cell_type_label is not None:
            
        #    ct_means = pd.DataFrame(se)
        #    ct_means[cell_type_label] = adata_tmp.obs[cell_type_label].values.copy()
        #    ct_means = ct_means.groupby(cell_type_label).median()
        #    #pd.DataFrame(df2_.T @ se, index = pd.get_dummies(adata_tmp.obs[cell_type_label]).columns.copy())
        #    se = se - ct_means.loc[adata_tmp.obs[cell_type_label].values].values
            
            
            se_list.append(se)
            r2_zlist.append(r2_z/Kfold)
            r2_slist.append(r2_s/Kfold)
            r2_zpvlist.append(return_f_pv(adata_tmp.X[ind],r2_z/Kfold))
            r2_spvlist.append(return_f_pv(latent_z[ind],r2_s/Kfold))
        if positivity_filter:
            return positive_indices, se_list, r2_zlist, r2_slist, r2_zpvlist, r2_spvlist, S
        else:
            return se_list, r2_zlist, r2_slist, r2_zpvlist, r2_spvlist, S
    else:
        se = np.zeros((latent_z.shape[0],adata_tmp.shape[1]))
        r2_z = np.zeros(adata_tmp.shape[1])
        r2_s = np.zeros(adata_tmp.shape[1])
        for ind in split_data:
            lr = LinearRegression()
            lr.fit(latent_z[ind],S[ind])
            lr2 = LinearRegression()
            lr2.fit(latent_z[ind],adata_tmp.X[ind])
            S_ = S[ind] - lr.predict(latent_z[ind])
            X_ = adata_tmp.X[ind] - lr2.predict(latent_z[ind])
            lr3 = LinearRegression()
            design_matrix = (latent_z[ind][:,:,None] * S_[:,None,:]).reshape(latent_z[ind].shape[0],latent_z.shape[1] * S_.shape[1])
            design_matrix = np.hstack((design_matrix,S_))
            lr3.fit(design_matrix,X_)
            se[ind] = lr3.predict(design_matrix)
            r2_z = r2_z + r2_score(adata_tmp.X[ind],lr2.predict(latent_z[ind]), multioutput='raw_values')
            r2_s = r2_s + r2_score(X_, lr3.predict(design_matrix), multioutput='raw_values')
        if positivity_filter:
            return positive_indices, se, r2_z/Kfold, r2_s/Kfold, return_f_pv(adata_tmp.X[ind],r2_z/Kfold), return_f_pv(adata_tmp.X[ind],r2_s/Kfold), S
        else:
            return se, r2_z/Kfold, r2_s/Kfold, return_f_pv(adata_tmp.X[ind],r2_z/Kfold), return_f_pv(adata_tmp.X[ind],r2_s/Kfold), S
            
import scanpy as sc

# 读取数据
adata_mtg = sc.read('mgcn_denoise_result/Spatial_MGCN.h5ad')
# 计算 PCA
sc.tl.pca(adata_mtg)

# 将 PCA 嵌入添加到 obsm
adata_mtg.obsm['simvi_z'] = adata_mtg.obsm['X_pca']
adata_mtg.obsm['simvi_s'] = adata_mtg.obsm['X_pca']



# 查看数据
# 查看 obsm 内容
print(adata_mtg.obsm.keys())

se_list, r2_zlist, r2_slist, r2_zpvlist, r2_spvlist, S = get_se(adata=adata_mtg,num_arch =7, Kfold=1,transformation = 'none',cell_type_label='ground_truth')
se = np.sum(se_list,axis=0)
adata_mtg.var['r2_z'] = np.max(r2_zlist,axis=0)
adata_mtg.var['r2_s'] = np.max(r2_slist,axis=0)


adata_mtg_ = adata_mtg.copy()
sc.pp.highly_variable_genes(adata_mtg_,n_top_genes=1000)
adata_mtg_ = adata_mtg_[:,adata_mtg_.var['means']>0.1]
adata_mtg_

from sklearn.linear_model import HuberRegressor

hr = HuberRegressor()
hr.fit(adata_mtg_.var['r2_z'].values.reshape(-1,1),adata_mtg_.var['r2_s'].values)


adata_mtg_.var['class'] = 'Others'

adata_mtg_.var['class'][adata_mtg_.var['r2_z']>0.6] = 'Intrinsic-specific'
adata_mtg_.var['class'][np.abs(adata_mtg_.var['r2_s'].values - hr.predict(adata_mtg_.var['r2_z'].values.reshape(-1,1)) ) / hr.scale_ > 5] = 'Spatial-induced'



# plt.rcParams['figure.dpi'] = 500
# plt.rcParams["font.size"] = 18

import matplotlib.pyplot as plt


# adata_mtg_.uns['class_colors'] = ['#33a02c','#bdbdbd','#084594']
adata_mtg_.uns['class_colors'] = [
        '#b2182b',   # Nature经典红色
    '#bdbdbd',  # 保留原灰色
    '#2166ac',  # Nature经典蓝色
]


sc.pl.scatter(adata_mtg_.copy(),x='r2_z',y='r2_s',show=False,color='class',size = 80)
plt.plot(adata_mtg_.var['r2_z'].values[np.argsort(adata_mtg_.var['r2_z'].values)],hr.predict(adata_mtg_.var['r2_z'].values.reshape(-1,1))[np.argsort(adata_mtg_.var['r2_z'].values)])

# for i in range(adata_mtg_.var['r2_s'].shape[0]):
#     if adata_mtg_.var['r2_s'][i] > 0.082:
#         plt.text(adata_mtg_.var['r2_z'][i]-0.05,adata_mtg_.var['r2_s'][i]-0.014,adata_mtg_.var_names[i],fontsize=12)
        
plt.xlabel('Intrinsic variation r^2')
plt.ylabel('Spatial effect r^2')
plt.title('')
# 保存高质量图像
plt.savefig('spatial_assessment.png', dpi=1000, bbox_inches='tight')  # 保存为PNG格式，300 DPI

plt.show()
