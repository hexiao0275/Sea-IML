#-*- coding : utf-8 -*-
import os,csv,re
import pandas as pd
import numpy as np
import scanpy as sc
import matplotlib.pyplot as plt
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score
from stMMR.utils import *
from stMMR.process import *
from stMMR import train_model
import argparse
import sklearn
import gc

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

# device = torch.device('cpu') 
def load_data(dataset):
    print("load Spatial mgcn data:")
    path = "Data/DLPFC_1/" + dataset + "/Spatial_MGCN.h5ad"
    adata = sc.read_h5ad(path)


    input_dir = os.path.join('Data/DLPFC/',dataset)
    adata_2 = sc.read_visium(path=input_dir, count_file=dataset+'_filtered_feature_bc_matrix.h5')

    cells_1 = adata.obs.index
    cells_2 = adata_2.obs.index

    unique_cells_2 = cells_2.difference(cells_1)


    cell_indices = [adata_2.obs.index.get_loc(cell) for cell in unique_cells_2]

   # print(f"Unique cells in adata_2: {unique_cells_2}")
    print(f"Indices of these unique cells in adata_2: {cell_indices}")

    features = torch.FloatTensor(adata.X)
    labels = adata.obs['ground']
    fadj = adata.obsm['fadj']
    sadj = adata.obsm['sadj']
    nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    graph_nei = torch.LongTensor(adata.obsm['graph_nei'])
    graph_neg = torch.LongTensor(adata.obsm['graph_neg'])
    print("done")
    return adata, features, labels, nfadj, nsadj, graph_nei, graph_neg,cell_indices


def load_data_text(dataset):
    print("load Spatial mgcn data:")
    path = "generate_data/DLPFC/" + dataset + "/Spatial_MGCN.h5ad"
    adata = sc.read_h5ad(path)
    features = torch.FloatTensor(adata.X)
    labels = adata.obs['ground']
    fadj = adata.obsm['fadj']
    sadj = adata.obsm['sadj']
    nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    graph_nei = torch.LongTensor(adata.obsm['graph_nei'])
    graph_neg = torch.LongTensor(adata.obsm['graph_neg'])
    print("done")
    return adata, features, labels, nfadj, nsadj, graph_nei, graph_neg


def spatial_construct_graph1(adata, radius=50):

    coor = pd.DataFrame(adata.obsm['spatial'])
    coor.index = adata.obs.index
    coor.columns = ['imagerow', 'imagecol']
    A=np.zeros((coor.shape[0],coor.shape[0]))

    # print("coor:", coor)
    nbrs = sklearn.neighbors.NearestNeighbors(radius=radius).fit(coor)
    distances, indices = nbrs.radius_neighbors(coor, return_distance=True)

    for it in range(indices.shape[0]):
        A[[it] * indices[it].shape[0], indices[it]]=1

    print('The graph contains %d edges, %d cells.' % (sum(sum(A)), adata.n_obs))
    print('%.4f neighbors per cell on average.' % (sum(sum(A)) / adata.n_obs))

    graph_nei = torch.from_numpy(A)

    graph_neg = torch.ones(coor.shape[0],coor.shape[0]) - graph_nei

    sadj = sp.coo_matrix(A, dtype=np.float32)
    sadj = sadj + sadj.T.multiply(sadj.T > sadj) - sadj.multiply(sadj.T > sadj)
    # nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    # nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    return sadj, graph_nei, graph_neg#, nsadj

def process_genes_and_adata(input_dir_text, adata,n_top_genes=128):
    # 读取文本文件中的基因名称
    with open(input_dir_text, "r") as file:
        text_genes_txt = file.read().splitlines()

    gene_text = pd.Series(False, index=adata.var_names)


    for gene in text_genes_txt:
        if gene in adata.var_names:
            gene_text.loc[gene] = True

    true_count = gene_text.sum()
    print("Number of True values in gene_text:", true_count)

    adata_text = adata[:, gene_text]

    sc.pp.highly_variable_genes(adata_text, flavor="seurat_v3", n_top_genes=true_count)

    # sc.pp.normalize_per_cell(adata_text)
    sc.pp.normalize_total(adata_text)


    sc.pp.log1p(adata_text)

    return adata_text


# section_ids = [151507, 151508, 151509, 151510, 151669, 151670, 151671, 151672, 151673, 151674, 151675, 151676] # 0.001
# section_ids = [151507, 151508, 151509, 151510]
# section_ids = [ 151669,151670, 151671, 151672, 151673, 151674, 151675, 151676] # 0.01
section_ids = [151507]

result_file = "dpl_result_save/ARI_NMI_results_multi_rand_MOE_image.txt"

with open(result_file, "w") as f:
    for section_id in section_ids:
        section_id = str(section_id)
        k = 7  # 
        im_re = pd.read_csv(os.path.join('Data/DLPFC/', section_id, "image_representation/ViT_pca_representation.csv"),
                            header=0, index_col=0, sep=',')
        
        print(section_id, k)
        input_dir = os.path.join('Data/DLPFC/', section_id)

        adata, features, labels, fadj, sadj, graph_nei, graph_neg,cell_indices = load_data(section_id)

        cell_indices = sorted(cell_indices)  
        mask = pd.Series(True, index=im_re.index)
        mask[cell_indices] = False 
        im_re_filtered = im_re[mask]
        adata.obsm["im_re"] = im_re_filtered

        adata_text_all, _, _, _, _, _, _ = load_data_text(section_id)
        
        input_dir_text = 'Data/DLPFC/text_guide_gene.txt'
        adata_text = process_genes_and_adata(input_dir_text, adata_text_all, n_top_genes=128)

        # adata = adata[:, adata.var['highly_variable']]
        adata.text = adata_text

        Ann_df = pd.read_csv(os.path.join('Data/DLPFC/', section_id, "cluster_labels_" + section_id + '.csv'), sep=',', header=0, index_col=0)
        adata.obs['ground_truth'] = Ann_df.loc[adata.obs_names, 'ground_truth']

        Ann_df = Ann_df.replace(1, "Layer 1").replace(2, "Layer 2").replace(3, "Layer 3").replace(4, "Layer 4").replace(5, "Layer 5").replace(6, "Layer 6").replace(7, "WM")
        adata.obs['Ground Truth'] = Ann_df.loc[adata.obs_names, 'ground_truth']

        _, graph_nei_sp, graph_neg_sp = spatial_construct_graph1(adata, radius=560)
        _, graph_nei, graph_neg = spatial_construct_graph1(adata, radius=150)

        sadj = sadj.to(device)

        positions = adata.obsm['spatial']  
        fadj = torch.tensor(positions, dtype=torch.float64).to(device)

        graph_nei_np = graph_nei.numpy()
        graph_neg_np = graph_neg.numpy()

        adata.obsm["graph_nei"] = graph_nei_np
        adata.obsm["graph_neg"] = graph_neg_np
        adata.obsm["graph_nei_sp"] = graph_nei_sp.numpy()
        adata.obsm["graph_neg_sp"] = graph_neg_sp.numpy()


        # lr=0.01, lr=0.001,s
        rand_seeds = [300,700]
        for seed in rand_seeds:
            adata = train_model.train(adata, fadj, sadj, knn=k,fft_ratio=0.1, n_epochs=200, h=[128, 8], lr=0.001, enhancement=False, radius=0, random_seed=seed)

            # 计算ARI和NMI
            obs_df = adata.obs.dropna()
            ARI = adjusted_rand_score(obs_df['stMMR'], obs_df['Ground Truth'])
            NMI = normalized_mutual_info_score(obs_df['stMMR'], obs_df['Ground Truth'])
            print(f'Section ID: {section_id}, Adjusted Rand Index (ARI) = {ARI:.2f}, Normalized Mutual Information (NMI) = {NMI:.2f}')
            sc.pl.spatial(adata, color=["stMMR", "Ground Truth"],
                        title=['stMMR (ARI=%.2f NMI=%.2f)' % (ARI, NMI), "Ground Truth"],
                        save=section_id)
        
            f.write(f'Section ID: {section_id}, Rand Seed: {seed}, ARI: {ARI:.2f}, NMI: {NMI:.2f}\n')
            f.flush()  #
            print(f'Section ID: {section_id}, Rand Seed: {seed}, Adjusted Rand Index (ARI) = {ARI:.2f}, Normalized Mutual Information (NMI) = {NMI:.2f}')

