
import numpy as np
import scanpy as sc
from matplotlib import pyplot as plt
import os
import pandas as pd
adata = sc.read_h5ad('mgcn_denoise_result/Spatial_MGCN.h5ad')
savepath = 'mgcn_denoise_result/Denoise/'


sc.tl.rank_genes_groups(
    adata, 
    groupby='idx',  # Assuming 'idx' contains cluster labels
    method='wilcoxon',
    n_genes=1,     # Top 50 markers per cluster
    use_raw=False
) 

result = adata.uns['rank_genes_groups']

marker_genes = pd.DataFrame({
    'group': result['names'].dtype.names,
    'names': [result['names'][group] for group in result['names'].dtype.names]
})
# 展开数据框，使每个基因占一行
marker_genes = marker_genes.explode('names')

# 输出所有marker基因
print("Top 50 marker genes per cluster:")
print(marker_genes.to_string(index=False))


if not os.path.exists(savepath):
    os.mkdir(savepath)

# marker_genes = ['ATP2B4', 'FKBP1A', 'CRYM', 'NEFH', 'RXFP1', 'B3GALT2']#, 'NTNG2'
marker_genes = ['ALB', 'LINC00645', 'COX6C', 'CRISP3', 'CXCL14', 'IGFBP7', 'CPB1', 'IGHG1', 'IFI27', 'MGP', 'APOE', 'IGLC2', 'IGKC', 'APOE', 'CPB1', 'LYZ', 'ALB', 'IGLC2', 'ALB', 'SAA1']
names=np.array(adata.var_names)

plt.rcParams["figure.figsize"] = (3, 3)
for gene in marker_genes:
    if np.isin(gene, np.array(adata.var_names)):
        sc.pl.spatial(adata, img_key="hires", color=gene, show=False, title=gene, layer='X', vmax='p99')
        plt.savefig(savepath + gene + '_raw.jpg', bbox_inches='tight', dpi=600)
        # plt.show()

        sc.pl.spatial(adata, img_key="hires", color=gene, show=False, title=gene, layer='mean',
                      vmax='p99')
        plt.savefig(savepath + gene + '_mean.jpg', bbox_inches='tight', dpi=600)
        # plt.show()


# sc.pl.stacked_violin(adata, marker_genes, title='Raw', groupby='ground_truth', swap_axes=True,
#                      figsize=[6, 3], show=False)
# plt.savefig(savepath + 'stacked_violin_Raw.jpg', bbox_inches='tight', dpi=600)
# plt.show()

# sc.pl.stacked_violin(adata, marker_genes, layer='mean', title='Spatial-MGCN', groupby='ground_truth', swap_axes=True,
#                      figsize=[6, 3], show=False)
# plt.savefig(savepath + 'stacked_violin_Spatial_MGCN.jpg', bbox_inches='tight', dpi=600)
# plt.show()


# Ensure ground_truth is a string type
adata.obs['ground_truth'] = adata.obs['ground_truth'].astype(str)

# Now create the stacked violin plot
sc.pl.stacked_violin(adata, marker_genes, layer='mean', title='Spatial-MGCN',
                     groupby='ground_truth', swap_axes=True,
                     figsize=[6, 3], show=False)

# Save the plot
plt.savefig(savepath + 'stacked_violin_Spatial_MGCN.jpg', bbox_inches='tight', dpi=600)
plt.show()