#-*- coding : utf-8 -*-
import os,csv,re
import pandas as pd
import numpy as np
import scanpy as sc

import scipy.io
import numpy as np
import scanpy as sc
import os

# 0. 确保输出目录存在
output_dir = os.path.join("generate_data", "Trento")
os.makedirs(output_dir, exist_ok=True)  # 如果目录不存在则创建

# 1. 加载 HSI 数据（Trento.mat）
mat_data = scipy.io.loadmat('Data/HSI_data/Trento.mat')
print("Trento.mat 中的变量:", mat_data.keys())  # 检查变量名

# 假设 HSI 数据存储在 'Trento' 变量中（根据实际情况调整）
hsi_cube = mat_data['HSI']  # 形状: [height, width, num_bands]
height, width, num_bands = hsi_cube.shape

# 2. 加载地物标签（Trento_gt.mat）
gt_data = scipy.io.loadmat('Data/HSI_data/Trento_gt.mat')
print("Trento_gt.mat 中的变量:", gt_data.keys())  # 检查变量名
print(f"HSI数据维度 - 高度: {height}, 宽度: {width}, 波段数: {num_bands}")
# 假设地物标签存储在 'gt' 变量中
print("Trento.mat 中的变量:", gt_data.keys())  # 检查变量名
gt_labels = gt_data['GT']  # 形状: [height, width]

# 3. 转换为 Scanpy 的 AnnData 格式
# 将 HSI 数据展平为 2D 矩阵 [n_pixels, n_bands]
hsi_2d = hsi_cube.reshape(-1, num_bands)

# 创建 AnnData 对象
adata = sc.AnnData(hsi_2d)

# 添加空间坐标（像素位置）
adata.obsm['spatial'] = np.array([
    [i, j] for i in range(height) for j in range(width)
])

# 添加地物标签（ground truth）
adata.obs['ground_truth'] = gt_labels.reshape(-1)  # 展平为 [n_pixels]

# 4. 处理波段信息（如果没有 'bands'，则用 1, 2, 3... 代替）
if 'bands' in mat_data:
    adata.var['wavelength'] = mat_data['bands'].flatten()  # 添加真实波段波长
else:
    adata.var['wavelength'] = np.arange(1, num_bands + 1)  # 默认波段编号 1, 2, 3...

# 5. 保存到 hsi_to_scanpy/Trento.h5ad
output_path = os.path.join(output_dir, "Trento.h5ad")
adata.write(output_path)

# 输出结果
print(f"转换完成！数据已保存到: {output_path}")
print(adata)