#-*- coding : utf-8 -*-
import os,csv,re
import pandas as pd
import numpy as np
import scanpy as sc
import matplotlib.pyplot as plt
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score
from stMMR.utils import *
from stMMR.process import *
from stMMR import train_model_mba
from datetime import datetime
import sklearn
from sklearn.metrics import confusion_matrix
from scipy.optimize import linear_sum_assignment



device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def spatial_construct_graph1(adata, radius=50):

    coor = pd.DataFrame(adata.obsm['spatial'])
    coor.index = adata.obs.index
    coor.columns = ['imagerow', 'imagecol']
    A=np.zeros((coor.shape[0],coor.shape[0]))

    # print("coor:", coor)
    nbrs = sklearn.neighbors.NearestNeighbors(radius=radius).fit(coor)
    distances, indices = nbrs.radius_neighbors(coor, return_distance=True)

    for it in range(indices.shape[0]):
        A[[it] * indices[it].shape[0], indices[it]]=1

    print('The graph contains %d edges, %d cells.' % (sum(sum(A)), adata.n_obs))
    print('%.4f neighbors per cell on average.' % (sum(sum(A)) / adata.n_obs))

    graph_nei = torch.from_numpy(A)

    graph_neg = torch.ones(coor.shape[0],coor.shape[0]) - graph_nei

    sadj = sp.coo_matrix(A, dtype=np.float32)
    sadj = sadj + sadj.T.multiply(sadj.T > sadj) - sadj.multiply(sadj.T > sadj)
    # nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    # nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    return sadj, graph_nei, graph_neg#, nsadj

def load_data(dataset):
    print("load Spatial mgcn data:")
    path = "Data/" + dataset + "/Spatial_MGCN.h5ad"
    adata = sc.read_h5ad(path)
    features = torch.FloatTensor(adata.X)
    labels = adata.obs['ground']
    fadj = adata.obsm['fadj']
    sadj = adata.obsm['sadj']
    nfadj = normalize_sparse_matrix(fadj + sp.eye(fadj.shape[0]))
    nfadj = sparse_mx_to_torch_sparse_tensor(nfadj)
    nsadj = normalize_sparse_matrix(sadj + sp.eye(sadj.shape[0]))
    nsadj = sparse_mx_to_torch_sparse_tensor(nsadj)
    graph_nei = torch.LongTensor(adata.obsm['graph_nei'])
    graph_neg = torch.LongTensor(adata.obsm['graph_neg'])
    print("done")
    return adata, features, labels, nfadj, nsadj, graph_nei, graph_neg


def process_genes_and_adata(input_dir_text, adata,n_top_genes=128):
    with open(input_dir_text, "r") as file:
        text_genes_txt = file.read().splitlines()

    gene_text = pd.Series(False, index=adata.var_names)

    for gene in text_genes_txt:
        if gene in adata.var_names:
            gene_text.loc[gene] = True


    true_count = gene_text.sum()
    print("Number of True values in gene_text:", true_count)

    adata_text = adata[:, gene_text]

    sc.pp.highly_variable_genes(adata_text, flavor="seurat_v3", n_top_genes=true_count)


    return adata_text

database = "Mouse_Brain_Anterior"
section_id = "V1_Mouse_Brain_Sagittal_Anterior_Section_1"

k=52

im_re = pd.read_csv(os.path.join('Data',
              "V1_Mouse_Brain_Sagittal_Anterior_Section_1", "image_representation/ViT_pca_representation.csv"), header=0, index_col=0, sep=',')
print(section_id, k)

adata, features, labels, fadj, sadj, graph_nei, graph_neg = load_data(database)

input_dir_text = 'Data/Mouse_Brain_Anterior/text_guide_gene_MBA_real.txt'
adata_text = process_genes_and_adata(input_dir_text, adata, n_top_genes=64)
adata.text = adata_text

adata.obsm["im_re"] = im_re

Ann_df = pd.read_csv("Data/{}/metadata.tsv".format(section_id), sep="	", header=0, na_filter=False,
                     index_col=0)
adata.obs['Ground Truth'] = Ann_df.loc[adata.obs_names, 'ground_truth']
adata.obs['ground_truth'] = adata.obs['Ground Truth']

_, graph_nei_sp, graph_neg_sp = spatial_construct_graph1(adata, radius=560)
_, graph_nei, graph_neg = spatial_construct_graph1(adata, radius=150)




positions = adata.obsm['spatial']  
fadj = torch.tensor(positions, dtype=torch.float64).to(device)

sadj = sadj.to(device)
fadj = fadj.to(device)

graph_nei_np = graph_nei.numpy()
graph_neg_np = graph_neg.numpy()

# adata.obsm["sadj_sp"] = sadj_sp
adata.obsm["graph_nei"] = graph_nei_np
adata.obsm["graph_neg"] = graph_neg_np
adata.obsm["graph_nei_sp"] = graph_nei_sp.numpy()
adata.obsm["graph_neg_sp"] = graph_neg_sp.numpy()


rand_seeds = [ 142316]

best_ari = -1
best_nmi = -1
best_seed = None
results = []  # 
adata_temp = []

for seed in rand_seeds:

    adata = train_model_mba.train(adata, fadj, sadj,  knn=52, n_epochs=300, h=[128, 32], lr=0.001, enhancement=False, radius=0, random_seed=seed)

    # 移除空值
    obs_df = adata.obs.dropna()


    ARI = adjusted_rand_score(obs_df['stMMR'], obs_df['Ground Truth'])
    NMI = normalized_mutual_info_score(obs_df['stMMR'], obs_df['Ground Truth'])

    print('Random Seed = %d, Adjusted Rand Index = %.5f, Normalized Mutual Information = %.5f' % (seed, ARI, NMI))
    

    results.append((seed, ARI, NMI))

    if ARI > best_ari:
        best_ari = ARI
        best_seed = seed
        adata_temp = adata
    if NMI > best_nmi:
        best_nmi = NMI


# from stMMR.mclust_utils import clustering
# os.environ['R_HOME'] = '/home/hexiao/miniconda3/envs/cellplm/lib/R'
# clustering(adata, n_clusters = k, radius=100, method='mclust', refinement=True) # For DLPFC dataset, we use optional refinement step.

# from sklearn import metrics
# ARI = metrics.adjusted_rand_score(adata.obs['domain'], adata.obs['ground_truth'])
# NMI = metrics.normalized_mutual_info_score(adata.obs['domain'], adata.obs['ground_truth'])

print("\nAll Seed Results:")
for seed, ari, nmi in results:
    print(f"Seed: {seed}, ARI: {ari:.5f}, NMI: {nmi:.5f}")